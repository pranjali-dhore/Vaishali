package org.capstore.domain;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.tool.hbm2ddl.SchemaExport;
import org.capstore.domain.*;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*AnnotationConfiguration  config = new AnnotationConfiguration();
		config.configure();
		SessionFactory sessionfactory = config.buildSessionFactory();
		Session session = sessionfactory.openSession();
		session.beginTransaction();
	    Customer1 cust = new Customer1();
		session.save(cust);
		session.getTransaction().commit();
		session.close();*/
	AnnotationConfiguration config=new AnnotationConfiguration();
		config.addAnnotatedClass(Customer1.class);
		config.configure();
		//Re-create the schema EveryTime
		new SchemaExport(config).create(true, true);
	}

}
