package org.capstore.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import org.capstore.domain.Customer;
import org.capstore.domain.Customer1;
import org.capstore.domain.Login;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import java.security.*;

import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import javax.management.Query;

import sun.misc.*;


@Repository
public class CustomerDaoImpl implements CustomerDao {

	 private static final String ALGO = "AES";
	    private static final byte[] keyValue = 
	        new byte[] { 'T', 'h', 'e', 'B', 'e', 's', 't',
	'S', 'e', 'c', 'r','e', 't', 'K', 'e', 'y' };

	public static String encrypt(String Data) throws Exception {
	        Key key = generateKey();
	        Cipher c = Cipher.getInstance(ALGO);
	        c.init(Cipher.ENCRYPT_MODE, key);
	        byte[] encVal = c.doFinal(Data.getBytes());
	        String encryptedValue = new BASE64Encoder().encode(encVal);
	        return encryptedValue;
	    }

	    public static String decrypt(String encryptedData) throws Exception {
	        Key key = generateKey();
	        Cipher c = Cipher.getInstance(ALGO);
	        c.init(Cipher.DECRYPT_MODE, key);
	        byte[] decordedValue = new BASE64Decoder().decodeBuffer(encryptedData);
	        byte[] decValue = c.doFinal(decordedValue);
	        String decryptedValue = new String(decValue);
	        return decryptedValue;
	    }
	    private static Key generateKey() throws Exception {
	        Key key = new SecretKeySpec(keyValue, ALGO);
	        return key;
	}
	    
	    
@Autowired
	private SessionFactory sessionFactory;
 @Transactional
	@Override
	public void saveCustomer(Customer customer) {
		
	 	String staticPart = "http://www.yoursite.com/foo/";

			//randomly generate the integer number and store in variable (e.g. ranNum)

			int ranNum = (int) (Math.random()*1000);
			String finalURL = staticPart + Integer.toString(ranNum);
	 
	  Session session = this.sessionFactory.getCurrentSession();
	    session.beginTransaction();
		customer.setRegdate(new Date());
		customer.setVerification_code(finalURL);
		customer.setEmail_verified(0);
		int car=(int) (Math.random()*5000);
		System.out.println(car);
		customer.setCart_id(car);
		
		String passwordEnc=null;
		try {
			passwordEnc = encrypt(customer.getPassword());
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		customer.setPassword(passwordEnc);
		sessionFactory.getCurrentSession().save(customer);
		session.getTransaction().commit();
	    //session.close();   
	}

@Override
public Customer searchCustomer(String email_id) {
	// TODO Auto-generated method stub
	 Session session = this.sessionFactory.getCurrentSession();
	Transaction tx=session.beginTransaction();
	Customer cust=(Customer) sessionFactory.getCurrentSession().createQuery("select * from customer where email_id " + email_id);
	return cust;
}

@Override
public void deletecustomer(String email_id) {
	// TODO Auto-generated method stub
	Customer cust1=(Customer) sessionFactory.getCurrentSession().get(Customer.class, email_id);
	if(cust1!=null)
		sessionFactory.getCurrentSession().delete(cust1);
}
/*
@Override
public Customer updateCustomer( String password,String email_id)
{
	
	Session session = sessionFactory.openSession();
	 session.beginTransaction();
    Customer cust1=(Customer) sessionFactory.getCurrentSession().createQuery("UPDATE customer SET PASSWORD="+ password +" WHERE email_id='"+ email_id +"'");
session.getTransaction().commit();
	session.close();
	return cust1;
	
}*/

@Override
public void saveLogin(Login login) {
	  Session session = this.sessionFactory.getCurrentSession();
	    session.beginTransaction();
	    sessionFactory.getCurrentSession().save(login);
		session.getTransaction().commit();
	
}

@Transactional
public boolean isvaliduser(Customer customer) {
			Session session=this.sessionFactory.getCurrentSession();
			session.beginTransaction();
			String sql = "select email_id,password from Customer where"
					+ " email_id='"+ customer.getEmail_id()+"'"
					+ " and password='"+ customer.getPassword()+"'";
			List <Objects []> rows = sessionFactory.getCurrentSession().createQuery(sql).list();
			if(rows.isEmpty())
				return false;
			else
				return true;
		
	}



@Override
@Transactional
public void updateCustomer(Customer customer) {

	Session session=this.sessionFactory.getCurrentSession();
	session.beginTransaction();
	// sessionFactory.getCurrentSession().saveOrUpdate(customer);
	
	/*String hqlUpdate = "update Customer c set c.password = :newName where c.email_id = :oldName";
	// or String hqlUpdate = "update Customer set name = :newName where name = :oldName";
	int updatedEntities = session.createQuery( hqlUpdate )
	        .setString( "newName", "werewe" )
	        .setString( "oldName", "dhore.pranjali08@gmail.com" )
	        .executeUpdate();
	//session.commit();
	session.close();*/
	
	String sql= "update Customer set password='"+customer.getPassword()+" ' where email_id='"+customer.getEmail_id()+"'";
	org.hibernate.Query query= sessionFactory.getCurrentSession().createQuery(sql);
	int count = query.executeUpdate();
	 
	session.getTransaction().commit();
	
}

@Override
public List<Customer> getAllCustomer() {
	Session session=this.sessionFactory.getCurrentSession();
	session.beginTransaction();
	List<Customer> custs=new ArrayList<>();
	custs=sessionFactory.getCurrentSession().createQuery("from customer").list();
	return custs;
}

@Override
public void saveCustomer(Customer1 customer1) {
	System.out.println("dao"+customer1);
 	String staticPart = "http://www.yoursite.com/foo/";

		//randomly generate the integer number and store in variable (e.g. ranNum)

		int ranNum = (int) (Math.random()*1000);
		String finalURL = staticPart + Integer.toString(ranNum);
 
  Session session = this.sessionFactory.getCurrentSession();
    session.beginTransaction();
	customer1.setRegdate(new Date());
	customer1.setVerification_code(finalURL);
	customer1.setEmail_verified(0);
	int car=(int) (Math.random()*5000);
	System.out.println(car);
	customer1.setCart_id(car);
	
	sessionFactory.getCurrentSession().save(customer1);
	session.getTransaction().commit();
	System.out.println("dao1"+customer1);
    //session.close();   
	
}

@Override
@Transactional
public  List<Customer1> ForgetCustomerPassword() {
	/*String sql= "Customer where  email_id ='"+customer1.getEmail_id();
	org.hibernate.Query query= sessionFactory.getCurrentSession().createQuery(sql);
	 query.executeUpdate();*/
	
	Session session = this.sessionFactory.getCurrentSession();
    session.beginTransaction();
    List<Customer1> customers1 = new ArrayList<>();
  customers1 = sessionFactory.getCurrentSession().createQuery("from Customer1").list();
    return customers1;
	
}

}




