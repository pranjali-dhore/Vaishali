package org.capstore.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.capstore.domain.Customer;
import org.capstore.domain.Customer1;
import org.capstore.domain.Login;
import org.capstore.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class CustomerController {
	

	
	@Autowired
	private CustomerService customerService;

	@RequestMapping("/customer")
	public String showCustomerPage(Map<String, Object> map){
		
				map.put( "customer", new Customer());
				return "customerRegister";
	}
	
	// Forget Password
	
	
	@RequestMapping("/customer1")
	public String showCustomerPage1(Map<String, Object> map){
		
				map.put( "customer1",new Customer1());
				return "saveCustomer";
	}
	@RequestMapping(value="/saveCustomer1",method=RequestMethod.POST)
	public ModelAndView saveCustomer1(@Valid @ModelAttribute("customer1") Customer1 customer1,
			BindingResult result){
		System.out.println(customer1);
		if(!result.hasErrors()){
			System.out.println(customer1);
			customerService.saveCustomer(customer1);
			return new ModelAndView("customer1");
		}else
		{
			return new ModelAndView("saveCustomer");
		}
	
	}
	
	
	@RequestMapping(value="/saveCustomer",method=RequestMethod.POST)
	public ModelAndView saveCustomer(@Valid @ModelAttribute("customer") Customer customer,
			BindingResult result){
		
		if(!result.hasErrors()){
			System.out.println(customer);
			customerService.saveCustomer(customer);
			return new ModelAndView("customer");
		}else
		{
			return new ModelAndView("customerRegister");
		}
	
	}
	
	
	@RequestMapping("/updateCustomerPwd")
	public String showChangePwdPage(Map<String, Object> map){
		
				map.put( "customer", new Customer());
				//map.put("custtype", getAllCustomerType().values());
				//map.put("customers", customerService.getAllCustomers());
				
				return "changePwd";
	}

	@RequestMapping(value="/updateCustomer",method=RequestMethod.POST)
	public String  updateCustomerPwd(@Valid @ModelAttribute("customer") Customer customer,
			BindingResult result,HttpServletRequest request){
		String password = customer.getPassword();
		String email_id= customer.getEmail_id();
		System.out.println(password+""+ email_id);
		  customerService.updateCustomer(customer);
		  System.out.println(customer);
	       return"redirect:/changePwd";
}
	
//forget password
	@RequestMapping("/customer2")
	public String showForgetPasswordPage(Map<String, Object> map){
		
				map.put( "customer1", new Customer1());
				return "ForgetPassword";
	}

	@RequestMapping(value="/ForgetPswd",method=RequestMethod.POST)
	public String  ForgetCustomerPwd(@Valid @ModelAttribute("customer1") Customer1 customer1,
			BindingResult result,HttpServletRequest request){
	/*	String password = customer1.getPassword();
		String email_id= customer1.getEmail_id();
		System.out.println(password+""+ email_id);
		*/
		
		List<Customer1> customers1 =  new ArrayList<>();
		customers1= customerService.ForgetCustomerPassword();
		int flag =0;
		for(Customer1 customer : customers1)
		{
			if(customer.getEmail_id()== request.getParameter("email_id") && customer.getUserSecurityquestion()==request.getParameter("userSecurityquestion") && customer.getUserSecurityanswer() ==request.getParameter("userSecurityanswer"))
			{
				
				System.out.println("valid user");
				flag=1;
			}
		}
	
		return "redirect:/changePwd";
		
		
		  
	    
}


	
/*	
	@RequestMapping("/login")
	public String validateUser(@ModelAttribute("login") Customer login,
			BindingResult result){
		
	Customer login = new Customer();
		login.setEmail_id("rahul@gmail.com");
		login.setPassword("rahul");
		
		
		
		return "login";
		
	}*/
	
/*
	@RequestMapping("/userlogin")
	public String showPage(@ModelAttribute("customer") Customer customer,BindingResult result)	
	{	System.out.println(customer);
		
		boolean flag = customerService.isvaliduser(customer);
	
		System.out.println(flag);
		if(flag)
			
			
			
			return "customer";
		else
			return "login";
	}
*/
/*
	@RequestMapping(value="/saveLogin",method=RequestMethod.POST)
	public ModelAndView saveCustomer(@Valid @ModelAttribute("login") Login login,
			BindingResult result){
		
		if(!result.hasErrors()){
			System.out.println(login);
			customerService.saveLogin(login);
			return new ModelAndView("login");
		}else
		{
			return new ModelAndView("login");
		}
	
	}
	*/
}

