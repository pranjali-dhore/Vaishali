package org.capstore.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.validator.constraints.Email;

@Entity
public class Customer1 {
	@Id
	@GeneratedValue
	private int	customer_id;
	
	//@Column(nullable=false)
	private String first_name;
	//@Column(nullable=false)
	private String last_name;
	/*private String country;
	private String state;
	private String city;
	private String pincode;
	private String street_name;
	private String  door_no;*/
	@Temporal(TemporalType.TIMESTAMP)
	private Date regdate;
	//@Column(nullable=false,unique=true)
	private String mobile_no;
	@Email
	//@Column(nullable=false)
	private String email_id;
	//@Column(nullable=false)
	private String password;
	
	private String verification_code;

	private int email_verified;

	private int cart_id;
	private String userSecurityquestion;
	private String userSecurityanswer;
	
	public Customer1(){}
	
	public Customer1(int customer_id, String first_name, String last_name, Date regdate, String mobile_no,
			String email_id, String password, String verification_code, int email_verified, int cart_id,
			String userSecurityquestion, String userSecurityanswer) {
		super();
		this.customer_id = customer_id;
		this.first_name = first_name;
		this.last_name = last_name;
		this.regdate = regdate;
		this.mobile_no = mobile_no;
		this.email_id = email_id;
		this.password = password;
		this.verification_code = verification_code;
		this.email_verified = email_verified;
		this.cart_id = cart_id;
		this.userSecurityquestion = userSecurityquestion;
		this.userSecurityanswer = userSecurityanswer;
	}
	public int getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public Date getRegdate() {
		return regdate;
	}
	public void setRegdate(Date regdate) {
		this.regdate = regdate;
	}
	public String getMobile_no() {
		return mobile_no;
	}
	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}
	public String getEmail_id() {
		return email_id;
	}
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getVerification_code() {
		return verification_code;
	}
	public void setVerification_code(String verification_code) {
		this.verification_code = verification_code;
	}
	public int getEmail_verified() {
		return email_verified;
	}
	public void setEmail_verified(int email_verified) {
		this.email_verified = email_verified;
	}
	public int getCart_id() {
		return cart_id;
	}
	public void setCart_id(int cart_id) {
		this.cart_id = cart_id;
	}
	public String getUserSecurityquestion() {
		return userSecurityquestion;
	}
	public void setUserSecurityquestion(String userSecurityquestion) {
		this.userSecurityquestion = userSecurityquestion;
	}
	public String getUserSecurityanswer() {
		return userSecurityanswer;
	}
	public void setUserSecurityanswer(String userSecurityanswer) {
		this.userSecurityanswer = userSecurityanswer;
	}
	@Override
	public String toString() {
		return "Customer1 [customer_id=" + customer_id + ", first_name=" + first_name + ", last_name=" + last_name
				+ ", regdate=" + regdate + ", mobile_no=" + mobile_no + ", email_id=" + email_id + ", password="
				+ password + ", verification_code=" + verification_code + ", email_verified=" + email_verified
				+ ", cart_id=" + cart_id + ", userSecurityquestion=" + userSecurityquestion + ", userSecurityanswer="
				+ userSecurityanswer + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + cart_id;
		result = prime * result + customer_id;
		result = prime * result + ((email_id == null) ? 0 : email_id.hashCode());
		result = prime * result + email_verified;
		result = prime * result + ((first_name == null) ? 0 : first_name.hashCode());
		result = prime * result + ((last_name == null) ? 0 : last_name.hashCode());
		result = prime * result + ((mobile_no == null) ? 0 : mobile_no.hashCode());
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		result = prime * result + ((regdate == null) ? 0 : regdate.hashCode());
		result = prime * result + ((userSecurityanswer == null) ? 0 : userSecurityanswer.hashCode());
		result = prime * result + ((userSecurityquestion == null) ? 0 : userSecurityquestion.hashCode());
		result = prime * result + ((verification_code == null) ? 0 : verification_code.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer1 other = (Customer1) obj;
		if (cart_id != other.cart_id)
			return false;
		if (customer_id != other.customer_id)
			return false;
		if (email_id == null) {
			if (other.email_id != null)
				return false;
		} else if (!email_id.equals(other.email_id))
			return false;
		if (email_verified != other.email_verified)
			return false;
		if (first_name == null) {
			if (other.first_name != null)
				return false;
		} else if (!first_name.equals(other.first_name))
			return false;
		if (last_name == null) {
			if (other.last_name != null)
				return false;
		} else if (!last_name.equals(other.last_name))
			return false;
		if (mobile_no == null) {
			if (other.mobile_no != null)
				return false;
		} else if (!mobile_no.equals(other.mobile_no))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		if (regdate == null) {
			if (other.regdate != null)
				return false;
		} else if (!regdate.equals(other.regdate))
			return false;
		if (userSecurityanswer == null) {
			if (other.userSecurityanswer != null)
				return false;
		} else if (!userSecurityanswer.equals(other.userSecurityanswer))
			return false;
		if (userSecurityquestion == null) {
			if (other.userSecurityquestion != null)
				return false;
		} else if (!userSecurityquestion.equals(other.userSecurityquestion))
			return false;
		if (verification_code == null) {
			if (other.verification_code != null)
				return false;
		} else if (!verification_code.equals(other.verification_code))
			return false;
		return true;
	}
	
	
	
}
