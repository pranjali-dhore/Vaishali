package org.capstore.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.capstore.domain.Customer;
import org.capstore.domain.Login;
import org.capstore.domain.OrderDetails;
import org.capstore.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class CustomerController {
	

	
	@Autowired
	private CustomerService customerService;

	@RequestMapping("/customer")
	public String showCustomerPage(Map<String, Object> map){
		
				map.put( "customer", new Customer());
				//map.put("custtype", getAllCustomerType().values());
				//map.put("customers", customerService.getAllCustomers());
				
				return "customerRegister";
	}
	
	@RequestMapping(value="/saveCustomer",method=RequestMethod.POST)
	public ModelAndView saveCustomer(@Valid @ModelAttribute("customer") Customer customer,
			BindingResult result){
		
		if(!result.hasErrors()){
			System.out.println(customer);
			customerService.saveCustomer(customer);
			return new ModelAndView("customer");
		}else
		{
			return new ModelAndView("customerRegister");
		}
	
	}
	
	
	@RequestMapping("/updateCustomerPwd")
	public String showChangePwdPage(Map<String, Object> map){
		
				map.put( "customer", new Customer());
				//map.put("custtype", getAllCustomerType().values());
				//map.put("customers", customerService.getAllCustomers());
				
				return "changePwd";
	}
	

	@RequestMapping(value="/updateCustomer",method=RequestMethod.POST)
	public String  updateCustomerPwd(@Valid @ModelAttribute("customer") Customer customer,
			BindingResult result,HttpServletRequest request){
	
		String password = customer.getPassword();
		String email_id= customer.getEmail_id();
		
		System.out.println(password+""+ email_id);
		  customerService.updateCustomer(customer);
		  
		  List<Customer> custs=new ArrayList<>();
		  custs=customerService.getAllCustomer();
		  for(Customer cust:custs)
				System.out.println("controller="+cust);
		  System.out.println(customer);
	       return"redirect:/changePwd";
}
	
	//get all orders
	
	
	@RequestMapping(value="/OrderDetails",method=RequestMethod.GET,
			produces={"application/json"})

	public String showOrderPage(Map<String, Object> map){
		  
				map.put( "order", new OrderDetails());
				System.out.println("hello");
				
				List<OrderDetails> orderslist=customerService.getAllOrders();
				
				 map.put("orders", orderslist);
	
				 
				
				return "OrderTable";
	}
}
	

