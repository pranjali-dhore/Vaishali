package org.capstore.domain;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class OrderDetails {

	
	@Id
	private int order_id;
	private String product_id;
	private String product_name;	
	private double net_amount;

	
	public OrderDetails(){}


	public OrderDetails(int order_id, String product_id, String product_name, double net_amount) {
		super();
		this.order_id = order_id;
		this.product_id = product_id;
		this.product_name = product_name;
		this.net_amount = net_amount;
	}


	public int getorder_id() {
		return order_id;
	}


	public void setorder_id(int corder_id) {
		this.order_id = corder_id;
	}


	public String getProduct_id() {
		return product_id;
	}


	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}


	public String getProduct_name() {
		return product_name;
	}


	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}


	public double getNet_amount() {
		return net_amount;
	}


	public void setNet_amount(double net_amount) {
		this.net_amount = net_amount;
	}


	@Override
	public String toString() {
		return "OrderDetails [order_id=" + order_id + ", product_id=" + product_id + ", product_name=" + product_name
				+ ", net_amount=" + net_amount + "]";
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + order_id;
		long temp;
		temp = Double.doubleToLongBits(net_amount);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((product_id == null) ? 0 : product_id.hashCode());
		result = prime * result + ((product_name == null) ? 0 : product_name.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrderDetails other = (OrderDetails) obj;
		if (order_id != other.order_id)
			return false;
		if (Double.doubleToLongBits(net_amount) != Double.doubleToLongBits(other.net_amount))
			return false;
		if (product_id == null) {
			if (other.product_id != null)
				return false;
		} else if (!product_id.equals(other.product_id))
			return false;
		if (product_name == null) {
			if (other.product_name != null)
				return false;
		} else if (!product_name.equals(other.product_name))
			return false;
		return true;
	}

	
	
	
}
