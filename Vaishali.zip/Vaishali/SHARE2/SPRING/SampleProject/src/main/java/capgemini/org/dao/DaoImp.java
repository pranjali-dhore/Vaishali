package capgemini.org.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import capgemini.org.com.Visitor;

public class DaoImp implements DaoInterface {


	private JdbcTemplate jdbcTemplate;
	private DataSource dataSource;
	
	public void setDataSource(DataSource dataSource) {
		this.dataSource=dataSource;
		jdbcTemplate=new JdbcTemplate(dataSource);
		
	}

	public void createVisitor(Visitor visitor) {
		String sql1="insert into address(doorNo, StName ,city, state) values(?,?,?,?)";
		jdbcTemplate.update(sql1,visitor.getAddress().getDoorNo(),visitor.getAddress().getStName(),visitor.getAddress().getCity(),visitor.getAddress().getState());
		int id=jdbcTemplate.queryForInt("select address_id from address order by address_id desc limit 1");
		String sql="insert into visitor(name,address_id) values(?,?)";
		jdbcTemplate.update(sql, visitor.getName(),id);
//		id=jdbcTemplate.queryForInt("select visitor_id from visitor order by visitor_id desc limit 1");
//		sql="update address set visitor_id =?";
//		jdbcTemplate.update(sql,id);
		
	}

	public void deleteVisitor(int empId) {
		// TODO Auto-generated method stub
		
	}

	public void updateVisitor(Visitor v) {
		// TODO Auto-generated method stub
		
	}

	public Visitor searchVisitor(int empId) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Visitor> getAllVisitor() {
		// TODO Auto-generated method stub
		return null;
	}

}
