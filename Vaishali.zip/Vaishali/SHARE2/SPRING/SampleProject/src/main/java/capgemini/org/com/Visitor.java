package capgemini.org.com;

public class Visitor {
	int visitor_id;
	String name;
	Address address;
	public int getVisitor_id() {
		return visitor_id;
	}
	public void setVisitor_id(int visitor_id) {
		this.visitor_id = visitor_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Visitor(int visitor_id, String name, Address address) {
		super();
		this.visitor_id = visitor_id;
		this.name = name;
		this.address = address;
	}
	public Visitor(){}
	@Override
	public String toString() {
		return "Visitor [visitor_id=" + visitor_id + ", name=" + name + ", address=" + address + "]";
	}
	

}
