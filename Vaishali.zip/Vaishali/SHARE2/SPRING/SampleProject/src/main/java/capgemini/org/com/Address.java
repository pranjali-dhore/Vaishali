package capgemini.org.com;

public class Address {

	int address_id;
	int doorNo;
	String stName;
	String city;
	String state;
	
	
	public int getAddress_id() {
		return address_id;
	}
	public void setAddress_id(int address_id) {
		this.address_id = address_id;
	}
	public int getDoorNo() {
		return doorNo;
	}
	public void setDoorNo(int doorNo) {
		this.doorNo = doorNo;
	}
	public String getStName() {
		return stName;
	}
	public void setStName(String stName) {
		this.stName = stName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public Address(int address_id, int doorNo, String stName, String city, String state) {
		super();
		this.address_id = address_id;
		this.doorNo = doorNo;
		this.stName = stName;
		this.city = city;
		this.state = state;
	}
	public Address(){}
	@Override
	public String toString() {
		return "Address [address_id=" + address_id + ", doorNo=" + doorNo + ", stName=" + stName + ", city=" + city
				+ ", state=" + state + "]";
	}
	
	
}
