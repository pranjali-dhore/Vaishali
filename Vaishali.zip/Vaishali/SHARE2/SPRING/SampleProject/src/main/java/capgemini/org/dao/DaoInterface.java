package capgemini.org.dao;

import java.util.List;

import javax.sql.DataSource;

import capgemini.org.com.Visitor;

public interface DaoInterface {
	public void setDataSource(DataSource dataSource);
	public void createVisitor(Visitor visitor);
	
	public void deleteVisitor(int empId);
	
	public void updateVisitor(Visitor v);
	
	public Visitor searchVisitor(int empId);
	
	public List<Visitor        > getAllVisitor();

}
