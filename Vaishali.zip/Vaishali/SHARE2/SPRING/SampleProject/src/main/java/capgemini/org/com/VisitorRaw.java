package capgemini.org.com;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class VisitorRaw implements RowMapper<Visitor>{

	public Visitor mapRow(ResultSet rs, int count) throws SQLException {
		Visitor visitor=new Visitor();
		visitor.setVisitor_id(rs.getInt(1));
		visitor.setName(rs.getString(2));
		visitor.setAddress((Address) rs.getObject(3));
		
		return visitor;

	}

	}


