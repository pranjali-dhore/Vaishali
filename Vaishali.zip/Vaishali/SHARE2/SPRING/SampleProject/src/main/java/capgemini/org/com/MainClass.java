package capgemini.org.com;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import capgemini.org.dao.DaoImp;

public class MainClass {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		ApplicationContext context=new ClassPathXmlApplicationContext("jdbcBeans.xml");
		
		DaoImp visitorDao=(DaoImp) context.getBean("jdbcTemp");
		
		System.out.println("Main Menu\n");
		System.out.println("1.Create Visitor\n");
		System.out.println("2.Update Visitor\n");
		System.out.println("3.Delete Visitor\n");
		System.out.println("4.Search Visitor\n");
		System.out.println("5.List All Visitor\n");
		System.out.println("Enter your choice:");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1: System.out.println("Enter Visitor Name");
				String name=sc.next();
				System.out.println("Enter Address");
				System.out.println("Enter DoorNo");
				int doorno=sc.nextInt();
				System.out.println("Enter Street Name");
				String streetname=sc.next();
				System.out.println("Enter City");
				String city=sc.next();
				System.out.println("Enter State");
				String state=sc.next();
				Address address=new Address();
				address.setDoorNo(doorno);
				address.setStName(streetname);
				address.setCity(city);
				address.setState(state);
				Visitor visitor=new Visitor();
				visitor.setName(name);
				visitor.setAddress(address);
				visitorDao.createVisitor(visitor);
		}
		
		/*Employee emp=new Employee(123, "John", 12000);
		Employee emp1=new Employee(1, "Tom", 45000);
		Employee emp2=new Employee(2, "ram", 67000);
		
		employeeDao.createEmployee(emp);
		employeeDao.createEmployee(emp1);
		employeeDao.createEmployee(emp2);*/
		//employeeDao.deleteEmployee(emp.getEmployeeId());
		
		
		/*Employee emp2=new Employee(2, "Sasi", 5500.0);
		employeeDao.updateEmployee(emp2);*/
		
		/*Employee emp=employeeDao.searchEmployee(452);
		
		System.out.println(emp);*/
		
//		List<Employee> employees=employeeDao.getAllEmployees();
//		
//		for(Employee emp:employees)
//			System.out.println(emp);
	}

}
