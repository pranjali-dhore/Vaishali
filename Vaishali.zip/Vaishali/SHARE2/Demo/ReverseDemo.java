import java.util.Scanner;

public class ReverseDemo
{
public static void main(String[] args)
{
    final int SIZE=10;
     Scanner sc=new Scanner(System.in);
	 
	 int[] myArr=new int[SIZE];
	 System.out.println("Enter the Numbers=");
	 for(int i=0;i<SIZE;i++)
	 {
	    myArr[i]=sc.nextInt();
	 }
	 System.out.println("Array Elements");
	 for(int i=0;i<myArr.length;i++)
	 {
	    System.out.println(myArr[i]);
		}
		System.out.println("Reverse Numbers");
		for(int i=SIZE-1;i>=0;i--)
	 {
	    System.out.println(myArr[i]);
		}
		
		}
		}
		