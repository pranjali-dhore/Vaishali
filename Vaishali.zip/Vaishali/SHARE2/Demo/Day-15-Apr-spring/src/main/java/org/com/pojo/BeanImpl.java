package org.com.pojo;



public class BeanImpl implements BeanPostProcessor
{
	public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
		System.out.println("postProcessAfterInitialization -->" +beanName );
			return bean;
		}

		public Object postProcessBeforeInitialization(Object bean, String  beanName) throws BeansException {
			System.out.println("postProcessBeforeInitialization -->" +beanName );
			return bean;
		}

}
