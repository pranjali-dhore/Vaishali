package com.ord.threaddemo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;
import java.util.TreeSet;

public class demo1 {

	public static void main(String[] args) {
		
		List list=new ArrayList();
		
		list.add("pune");
		list.add("chennai");
		list.add("hydrabad");
		list.add("mumbai");
		list.add("Banglore");
		//list.add(1);
		
       Iterator it=list.iterator();
       while(it.hasNext())
       {
    	   it.remove();
    	   System.out.println(list);
       }
	}

}
