package com.ord.threaddemo;

public class StringDemo {
	
	String str;
	
	public void printString(String str)
	{
		synchronized(this)
		{
		for(int i=0;i<str.length();i++)
		{
			for(int j=0;j<=i;j++)
			{
				System.out.print(str.charAt(j));
				
			}
			System.out.println();
		}
		}
	}
}


