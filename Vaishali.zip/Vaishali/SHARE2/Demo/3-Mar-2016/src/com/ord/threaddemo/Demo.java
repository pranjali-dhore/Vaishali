package com.ord.threaddemo;

public class Demo extends Thread{

	public static void main(String[] args) {
		StringDemo str=new StringDemo();
		
		Thread t=new Thread(){
		    @Override
		     public void run() {
			     str.printString("capgemini");
			
		       }
	};
	
	Thread t1=new Thread(){
	    @Override
	     public void run() {
		     str.printString("Welcome");
		
	       }
};
	t.start();
	t1.start();
	}
}

