package org.cap.demo;

public class MainClass {

	public static void main(String[] args) {
		Employee emp1=new Employee(1,"tom");
		Employee emp2=new Employee(1,"tom");
		
		System.out.println(emp1==emp2);
		System.out.println(emp1.equals(emp2));

	}

}
