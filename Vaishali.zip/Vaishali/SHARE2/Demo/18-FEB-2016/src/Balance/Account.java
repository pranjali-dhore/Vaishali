package Balance;

public class Account {
	
    public void DisplayBalance()
    {
    	System.out.println("Display Balance Method of Account Class");
    }

}
