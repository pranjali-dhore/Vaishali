package com.org.cap;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {


		Student student;
		
		System.out.println("1.Under Graduate Student");
		System.out.println("2.Post Graduate Student");
		
		Scanner sc=new Scanner(System.in);
		
	}

}
