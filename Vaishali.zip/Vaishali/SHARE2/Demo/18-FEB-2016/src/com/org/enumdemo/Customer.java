package com.org.enumdemo;

import java.util.Scanner;

public class Customer {
	
	private int custId;
	private String custName;
	private double regFees;
	CustomerType custType=CustomerType.SILVER;
	
	public void getCustDetails()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Customer Id=");
		custId=sc.nextInt();
		
		System.out.println("Enter Customer Name=");
		custName=sc.next();
		
		System.out.println("Enter Registration Fees=");
		regFees=sc.nextDouble();
		
		
	}

	public void printCustomerDetails()
	{
		System.out.println("Customer Id="+custId+"\n"+"Customer Name="+custName+"\n"+"Registration Fees="+regFees);
	}
}
