package com.org.InterfaceDemo;
import  Balance.Account;
public class MainClass {

	public static void main(String[] args) {
		InterfaceDemo demo=new InterfaceDemo();
		demo.getData();
		demo.division();
		demo.modules();
		Account account=new Account();
		account.DisplayBalance();

	}

}
