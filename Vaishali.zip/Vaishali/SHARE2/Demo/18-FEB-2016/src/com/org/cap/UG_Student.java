package com.org.cap;

import java.util.Scanner;

public class UG_Student implements Student {
	
     private float percentage;
	@Override
	public void displayGrade() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter percentage=");
		percentage=sc.nextFloat();
		
		System.out.println("Percentage="+percentage);
		
		if(percentage>=45 && percentage<=55)
			System.out.println("C Grade");
		else if(percentage>55 && percentage<=65)
			System.out.println("B Grade");
		else if(percentage>65 && percentage<=75)
			System.out.println("A Grade");
		else
			System.out.println("Distinction");
		
	}

	@Override
	public void attendance() {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter present days=");
		int noOfDays=sc.nextInt();
		int totalDays=300;
		System.out.println("Atttendance="+(totalDays-noOfDays));
		
	
		
	}

}
