package com.org.InterfaceDemo;

public interface DivisionDemo {
	public void division();
	public void modules();

}
