package com.org.enumdemo;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		Customer customer=new Customer();
		CustomerType custType;
		int minValue,maxValue;
		
		customer.getCustDetails();
		
		System.out.println("1.SILVER");
		System.out.println("2.GOLD");
		System.out.println("4.DIAMOND");
		System.out.println("4.PLATINUM");
		
		System.out.println("Enter Your Option=");
		int option=sc.nextInt();
		customer.printCustomerDetails();
		switch(option)

		{
		case 1:custType=CustomerType.SILVER;
		       minValue=custType.getminValue();
		       maxValue=custType.getmaxValue();
		       System.out.println("Customer Type="+custType+" "+minValue+"-"+maxValue);
		       break;
		case 2:custType=CustomerType.GOLD;
		           minValue=custType.getminValue();
	                 maxValue=custType.getmaxValue();
	                 System.out.println("Customer Type="+custType+" "+minValue+"-"+maxValue);
	       break;
		case 3:custType=CustomerType.DIAMOND;
		           minValue=custType.getminValue();
	                  maxValue=custType.getmaxValue();
	                  System.out.println("Customer Type="+custType+" "+minValue+"-"+maxValue);
	       break;
		case 4:custType=CustomerType.PLATINUM;
		        minValue=custType.getminValue();
	            maxValue=custType.getmaxValue();
	            System.out.println("Customer Type="+custType+" "+minValue+"-"+maxValue);
	       break;
		       
		}
	}

}
