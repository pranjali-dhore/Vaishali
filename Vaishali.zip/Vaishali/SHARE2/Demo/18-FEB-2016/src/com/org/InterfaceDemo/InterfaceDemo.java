package com.org.InterfaceDemo;
import  Balance.Account;
import java.util.Scanner;


public class InterfaceDemo implements DivisionDemo{

	private float number1,number2,division,modules;
	
	public void getData()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter two Number=");
		number1=sc.nextFloat();
		number2=sc.nextFloat();
		
		
	}
	@Override
	public void division() {
		division=(number1/number2);
		System.out.println("Division="+division);
		
	}

	@Override
	public void modules() {
		modules=(number1%number2);
		System.out.println("Modules="+modules);
		
	}

}
