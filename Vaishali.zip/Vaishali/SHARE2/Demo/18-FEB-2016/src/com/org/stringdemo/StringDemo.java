package com.org.stringdemo;

import java.util.Scanner;

public class StringDemo {
	
	private String str1;
	public void Demo()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter String=");
		str1=sc.next();
		//charAt
		System.out.println("Enter position=");
		int pos=sc.nextInt();
		System.out.println("CharAt="+str1.charAt(1));
		System.out.println("Ener Second String=");
		String str2=sc.next();
		//compareTo
		
			System.out.println(str1.compareTo(str2));
		
		//compareToIgnoreCase	
		
			System.out.println(str1.compareToIgnoreCase(str2));
	
		//concat
		
		System.out.println("Concatenated String="+str1.concat(str2));
		//contains
		System.out.println("Enter character=");
		String s=sc.next();
		
			System.out.println(str1.contains(s));
	
		//Ends With
		
		     System.out.println(str2.endsWith(str1));
		
		//equals
		
			System.out.println(str1.equals(str2));
		
		
		
	}
}
