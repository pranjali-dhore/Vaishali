package com.org.cap;

public interface Student {
	

	public  void displayGrade();
	public void attendance();

}
