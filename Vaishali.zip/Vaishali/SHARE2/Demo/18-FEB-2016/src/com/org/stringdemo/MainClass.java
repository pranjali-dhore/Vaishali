package com.org.stringdemo;

public class MainClass {

	public static void main(String[] args) {

        StringDemo string=new StringDemo();
        string.Demo();

	}

}
