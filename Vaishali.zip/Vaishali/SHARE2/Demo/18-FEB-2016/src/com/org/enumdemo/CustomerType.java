package com.org.enumdemo;

public enum CustomerType {
	
	SILVER(0,100),GOLD(101,300),DIAMOND(301,500),PLATINUM(501,100);
	int minValue,maxValue;
	
	 private CustomerType(int minValue,int maxValue)
	{
		this.minValue=minValue;
		this.maxValue=maxValue;
	}
	 public  int getminValue()
	 {
		 return minValue;
	 }
	 public int getmaxValue()
	 {
		 return maxValue;
	 }

}
