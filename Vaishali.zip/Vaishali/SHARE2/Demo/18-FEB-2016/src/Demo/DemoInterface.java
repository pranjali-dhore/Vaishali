package Demo;

public interface DemoInterface {

	public final int count=1;
}
