package Demo;

public class Demo implements DemoInterface {

	
	    //int count=2;
	   
	     public void demo()
	    {
		   //count++;
	    	   
	      System.out.println( DemoInterface.count);
	  
	  
	     }
}
