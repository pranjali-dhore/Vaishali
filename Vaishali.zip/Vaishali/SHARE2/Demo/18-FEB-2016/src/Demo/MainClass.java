

package Demo;

public class MainClass {

	public static void main(String[] args) {
		Demo d=new Demo();
		d.demo();

	}

}
