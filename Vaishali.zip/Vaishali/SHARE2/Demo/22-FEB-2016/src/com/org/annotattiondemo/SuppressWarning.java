package com.org.annotattiondemo;

public @interface SuppressWarning {

}
