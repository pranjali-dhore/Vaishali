package com.org.demo;

public interface MyConstants {
	int r = 42;
	int s = 69;

	int AREA = r * s;
	final double circumference = 2 * Math.PI * r;
	//int total = total + r + s;

}
