package com.org.demo;

public class MyClass {

	public static void main(String[] args) {
		A[] arrA;
		B[] arrB;
		arrA = new A[10];
		arrB = new B[20];
		arrA = arrB; // (1)
		arrB = (B[]) arrA; // (2)
		arrA = new A[10];
		arrB = (B[]) arrA; // (3)
		}
		}
		class A {}
		class B extends A {}


