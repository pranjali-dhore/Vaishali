package com.org.exceptiondemo;

public class Demo {

	public static void main(String[] args) {
		
         

          int num1,num2;
          int divide=0;
          try
          {
        	 
        	  num1=Integer.parseInt(args[0]);
        	  num2=Integer.parseInt(args[2]);
        	  divide=num1/num2;
        	  System.out.println(divide);
        	  
          }
          catch(ArithmeticException|NumberFormatException|ArrayIndexOutOfBoundsException e)
          {
        	 System.out.println(e.getMessage());
          }
        
	}
	

}
