package com.org.annotattiondemo;

public class MainClass {

	public static void main(String[] args) {
		@Publisher(publisherName="TATA",publishDate=30.0f)
		Book book=new Book(1,"Java",120.0f);
		
		//book.Details();
		System.out.println(book);
     
}
}