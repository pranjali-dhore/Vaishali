import java.util.Scanner;

public class MatrixAdd
{
   public static void main(String[] args)
   {
           int[][] myArr=new int[2][2];
	   int[][] myArr1=new int[2][2];
	   int[][] sum=new int[2][2];
	   Scanner sc=new Scanner(System.in);
	   System.out.println("Enter Array Elements For First Matrix=");
	   for(int i=0;i<2;i++)
	   {
	     for(int j=0;j<2;j++)
		 {
		     myArr[i][j]=sc.nextInt();
		 }
		}
		System.out.println("First Matrix Element");
		for(int i=0;i<2;i++)
	   {
	     for(int j=0;j<2;j++)
		 {
		    System.out.print(myArr[i][j]);
			System.out.print("\t");
			
		 }
		 System.out.println();
		}
		System.out.println("Enter Array Elements For Second Matrix=");
	   for(int i=0;i<2;i++)
	   {
	     for(int j=0;j<2;j++)
		 {
		     myArr1[i][j]=sc.nextInt();
		 }
		}
		System.out.println("Second Matrix Element");
		for(int i=0;i<2;i++)
	   {
	     for(int j=0;j<2;j++)
		 {
		    System.out.print(myArr1[i][j]);
			System.out.print("\t");
			
		 }
		 System.out.println();
		}
		System.out.println("Matrix Addition");
		for(int i=0;i<myArr.length;i++)
		{
		    for(int j=0;j<myArr1.length;j++)
			{
			    sum[i][j]=myArr[i][j]+myArr1[i][j];
				System.out.print(sum[i][j]);
				System.out.print("\t");
			}
			 System.out.println();
		}
		}
		}