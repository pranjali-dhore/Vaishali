import java.util.Scanner;

public class NumberDemo
{
public static void main(String[] args)
{
    int number,remainder=0;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Number=");
	number=sc.nextInt();
	
	     while(number!=0)
		 {
		  remainder=remainder*10;
		  remainder=remainder+number%10;
		  number=number/10;
		 System.out.println(remainder);
		 }
		 
		 }
		 }
	