import java.util.Scanner;


public class EmpBonus
{
     public static void main(String[] args)
      {
          String empName;
          float salary,bonusAmount;
          
          Scanner sc=new Scanner(System.in);
          
          System.out.println("Enter Employee Name=");
          empName=sc.next();
          
          System.out.println("Enter Salary=");
          salary=sc.nextFloat();

          if(salary>2000000)
             {
               System.out.println("Bonus Amount="+((salary*15)/100));
             }  
          else if(salary>=1000000 && salary<=2000000)
             {
               System.out.println("Bonus Amount="+((salary*20)/100));
             } 
           else if(salary>=500000 && salary<=1000000)
             {
               System.out.println("Bonus Amount="+((salary*25)/100));
             } 
           else if(salary<500000)
             {
               System.out.println("Bonus Amount="+((salary*30)/100));
             }    
      }
}