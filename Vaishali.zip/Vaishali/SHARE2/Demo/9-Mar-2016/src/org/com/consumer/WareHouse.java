package org.com.consumer;

import java.util.Stack;

public class WareHouse {
	
	private Stack<Integer> stack=new Stack<Integer>();
	
	public synchronized void add(int x)
	{
		if(stack.size()==10)
	      System.out.println("Stack is full producer have to wait");	
		   try {
			wait();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		   stack.push(x);
		   notify();
		   
	}   
		   public int remove()
		   {
			   synchronized(stack)
			   {
			   if(stack.isEmpty())
			   System.out.println("Stack is empty consumer have to wait");
			   try {
				stack.wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			   //stack.notify();
			   return stack.pop();
			   }	   
			   
		   }
		   
	}


