package org.com.demo;

public class MyThread extends Thread{
	
	static int i=0;
	public void run()
	{
		for(;i<10;i++)
			System.out.println("I="+i);
	}

}
