package org.com.consumer;

public class BootClass {

	public static void main(String[] args) {

		 WareHouse wh=new WareHouse();
		 Producer p1=new Producer(wh);
		Consumer c1=new Consumer(wh);
		 //Thread t1=new Thread(p1);
		 //Thread t2=new Thread(c1);
		 Thread[] t=new Thread[5];
		 
		 for(Thread t1:t)
		 {
			 t1=new Thread(c1);
			 t1.start();
		 }
		 t1.start();
		 t2.start();
        
	}

	
}
