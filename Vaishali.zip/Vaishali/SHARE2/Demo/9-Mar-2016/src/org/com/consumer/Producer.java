package org.com.consumer;

import java.util.Random;

public class Producer implements Runnable{

	private WareHouse wh;
	
	public Producer(WareHouse wh)
	{
		this.wh=wh;
	}
	@Override
	public void run() {
		
		while(true)
		{
			int x=new Random().nextInt(500);
			System.out.println("X="+x);
			wh.add(x);
		}
	}

}
