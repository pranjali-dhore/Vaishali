package org.com.consumer;

public class Consumer implements Runnable{

	private WareHouse wh;
	
	public Consumer(WareHouse wh)
	{
		this.wh=wh;
	}
	@Override
	public void run() {
		
		while(true)
		{
			wh.remove();
		}
	}

}
