package org.acap.dao;

import java.util.ArrayList;

import org.cap.model.Customer;
import org.cap.model.LoginUser;

public interface LoginDao {

	public boolean isValidLogin(LoginUser loginUser) ;
	public void SaveCustomerServlet(Customer customer);
	public ArrayList<Customer> getAllCustomers();
	
	public boolean deleteCustomer(int custId);
}
