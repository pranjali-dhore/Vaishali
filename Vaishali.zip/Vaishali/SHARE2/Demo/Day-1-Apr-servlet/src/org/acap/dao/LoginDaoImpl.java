package org.acap.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.cap.model.Customer;
import org.cap.model.LoginUser;

public class LoginDaoImpl implements LoginDao{
	
	
public Connection getConnection(){
		
		Connection connection=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/customer","root","Pass1234");
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return connection;
	}

	@Override
	public boolean isValidLogin(LoginUser loginUser) {
		boolean flag=false;
		Connection con=getConnection();
		String sql="select * from custlogin where username=? and userpass=?";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1, loginUser.getUserName());
			pst.setString(2, loginUser.getUserPwd());
			
			ResultSet rs=pst.executeQuery();
			
			if(rs.next())
				flag=true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return flag;
	}
	


	@Override
	public void SaveCustomerServlet(Customer customer) {
		
		Connection con=getConnection();
		
		String sql="insert into customer(firstname,lastname,address,gender,regdate,regfees,custtype)"+"values(?,?,?,?,?,?,?)";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1, customer.getFirstname());
			pst.setString(2, customer.getLastname());
			pst.setString(3, customer.getAddress());
			pst.setString(4, customer.getGender());
			pst.setDate(5, new Date(customer.getRegdate().getTime()));
			pst.setDouble(6, customer.getRegfee());
			pst.setString(7, customer.getCusttype());
			
			
			int count=pst.executeUpdate();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public ArrayList<Customer> getAllCustomers() {
		ArrayList<Customer> customers=new ArrayList<>();
		String str="select * from customer";
		Connection con=getConnection();
		
		try {
			PreparedStatement pst=con.prepareStatement(str);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				Customer cust=new Customer();
				cust.setCustid(rs.getInt(1));
				cust.setFirstname(rs.getString(2));
				cust.setLastname(rs.getString(3));
				cust.setAddress(rs.getString(4));
				cust.setGender(rs.getString(5));
				
				//dd-mmm-yyyy
				cust.setRegdate(rs.getDate(6).valueOf(rs.getDate(6).toString()));
				
				cust.setRegfee(rs.getDouble(7));
				cust.setCusttype(rs.getString(8));
				
				//Adding the customer into arraylist
				customers.add(cust);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return customers;
	}

	@Override
	public boolean deleteCustomer(int custId) {
		Connection con=getConnection();
		boolean flag=false;
		String sql="delete from customer where custid=?";
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1, custId);
	
			int count=pst.executeUpdate();
			
			if(count>0)
				flag=true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return flag;
	}
	}

