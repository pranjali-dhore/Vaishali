package org.cap.service;

import java.util.ArrayList;

import org.cap.model.Customer;
import org.cap.model.LoginUser;

public interface LoginService {

	public boolean isValidLogin(LoginUser loginUser);
	public void SaveCustomerServlet(Customer customer);
	public ArrayList<Customer> getAllCustomers();
	public boolean deleteCustomer(int parseInt);
}
