package org.cap.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.service.LoginService;
import org.cap.service.LoginServiceImpl;

/**
 * Servlet implementation class DeleteCust
 */
public class DeleteCust extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		String custid=request.getParameter("custid");
		LoginService loginService=new LoginServiceImpl();
		
		boolean flag=loginService.deleteCustomer(Integer.parseInt(custid));
		
		if(flag){
			request.getRequestDispatcher("deleteCustomerServlet").forward(request, response);
		}
	}

}
