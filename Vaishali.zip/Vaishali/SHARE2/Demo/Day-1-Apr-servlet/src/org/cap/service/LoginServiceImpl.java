package org.cap.service;

import java.util.ArrayList;

import org.acap.dao.LoginDao;
import org.acap.dao.LoginDaoImpl;
import org.cap.model.Customer;
import org.cap.model.LoginUser;

public class LoginServiceImpl implements LoginService{

	
	private LoginDao loginDao=new LoginDaoImpl();
	@Override
	public boolean isValidLogin(LoginUser loginUser) {
		

		return loginDao.isValidLogin(loginUser);
	
	}

	@Override
	public void SaveCustomerServlet(Customer customer) {
		loginDao.SaveCustomerServlet(customer);
		
	}

	@Override
	public ArrayList<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return loginDao.getAllCustomers();
	}

	@Override
	public boolean deleteCustomer(int custId) {
		return loginDao.deleteCustomer(custId);
	}

}
