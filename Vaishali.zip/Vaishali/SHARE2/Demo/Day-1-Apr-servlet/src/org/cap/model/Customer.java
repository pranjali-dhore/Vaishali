package org.cap.model;

import java.util.Date;

public class Customer {
	
	private int custid;
	private String firstname;
	private String lastname;
	private String address;
	private String gender;
	private Date regdate;
	private double regfee;
	private String custtype;
	
	
	public Customer(){}


	public Customer(int custid, String firstname, String lastname, String address, String gender, Date regdate,
			double regfee, String custtype) {
		super();
		this.custid = custid;
		this.firstname = firstname;
		this.lastname = lastname;
		this.address = address;
		this.gender = gender;
		this.regdate = regdate;
		this.regfee = regfee;
		this.custtype = custtype;
	}


	public int getCustid() {
		return custid;
	}


	public void setCustid(int custid) {
		this.custid = custid;
	}


	public String getFirstname() {
		return firstname;
	}


	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}


	public String getLastname() {
		return lastname;
	}


	public void setLastname(String lastname) {
		this.lastname = lastname;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public Date getRegdate() {
		return regdate;
	}


	public void setRegdate(Date regdate) {
		this.regdate = regdate;
	}


	public double getRegfee() {
		return regfee;
	}


	public void setRegfee(double regfee) {
		this.regfee = regfee;
	}


	public String getCusttype() {
		return custtype;
	}


	public void setCusttype(String custtype) {
		this.custtype = custtype;
	}


	@Override
	public String toString() {
		return "Customer [custid=" + custid + ", firstname=" + firstname + ", lastname=" + lastname + ", address="
				+ address + ", gender=" + gender + ", regdate=" + regdate + ", regfee=" + regfee + ", custtype="
				+ custtype + "]";
	}
	
	
	
	
	


}
