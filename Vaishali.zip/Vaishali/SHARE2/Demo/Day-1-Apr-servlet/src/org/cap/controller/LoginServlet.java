package org.cap.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.model.LoginUser;
import org.cap.service.LoginService;
import org.cap.service.LoginServiceImpl;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
PrintWriter out=response.getWriter();
		
		String userName=request.getParameter("uname");
		String userPwd=request.getParameter("upwd");
		
		LoginUser loginUser=new LoginUser();
		loginUser.setUserName(userName);
		loginUser.setUserPwd(userPwd);
		
		
		LoginService loginService=new LoginServiceImpl();
		
		
		
		if(loginService.isValidLogin(loginUser))
			//response.sendRedirect("SaveCustomerServle");
		request.getRequestDispatcher("/pages/success.html").forward(request, response);
		else
			response.sendRedirect("pages/login.html");
		
	}
	}


