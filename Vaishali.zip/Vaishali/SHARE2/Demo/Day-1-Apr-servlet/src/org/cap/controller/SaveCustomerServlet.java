package org.cap.controller;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.model.Customer;
import org.cap.service.LoginService;
import org.cap.service.LoginServiceImpl;

/**
 * Servlet implementation class SaveCustomerServlet
 */
public class SaveCustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		LoginService loginService=new LoginServiceImpl();
	   Customer customer=new Customer();
	   String fname=(request.getParameter("fname"));
	   customer.setFirstname(fname);
	   String lname=request.getParameter("lname");
	   customer.setLastname(lname);
	   String address=request.getParameter("address");
	   customer.setAddress(address);
	   String gender=request.getParameter("gender");
	   customer.setGender(gender);
	   
	   String date=request.getParameter("regdate");
	   Date regdate=new Date(date);
	   customer.setRegdate(regdate);
	   
	   double regfee=Double.parseDouble(request.getParameter("regfee"));
	   customer.setRegfee(regfee);
	   
	   String custtype=request.getParameter("custtype");
	   customer.setCusttype(custtype);
	   
	   System.out.println(customer);
	   
	   
	 //Persist employee Object into DataBase
	 		loginService.SaveCustomerServlet(customer);
	 		
	 		request.setAttribute("fname",fname);
	 		request.setAttribute("lname",lname);
	 		//request.setAttribute("fname",fname);
	 		
	 		//response.sendRedirect("SaveEmployeeServlet");
	 		request.getRequestDispatcher("pages/ListAllEmployee.jsp").forward(request, response);
	   
	   
	}

}
