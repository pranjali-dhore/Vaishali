package org.cap.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.acap.dao.LoginDao;
import org.cap.model.Customer;
import org.cap.service.LoginService;
import org.cap.service.LoginServiceImpl;

/**
 * Servlet implementation class SearchCustomer
 */
public class SearchCustomer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchCustomer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
        LoginService loginService=new LoginServiceImpl();
		
		ArrayList<Customer> customers=loginService.getAllCustomers();
		Customer cust1=new Customer();
		PrintWriter out=response.getWriter();
		int custid=Integer.parseInt(request.getParameter("searchcust"));
		
		LoginServiceImpl loginServ=new LoginServiceImpl();
		
		
		
		     
		out.println("<html>");
		out.println("<head>Search Customers</head>"
				+ "<body>"
				+ "<table>"
				+ "<tr>"
				+ "<th>Customer Id</th>"
				+ "<th>FirstName</th>"
				+ "<th>LastName</th>"
				+ "<th>Address</th>"
				+ "<th>Gender</th>"
				+ "<th>Registration Date</th>"
				+ "<th>Registration Fees</th>"
				+ "<th>Customer Type</th>"
				+ "</tr>");
		
			for(Customer cust:customers){
				 if(custid==cust.getCustid())
				 {
				out.println("<tr>");
				out.println("<td>"+"\t"+cust.getCustid()+"</td>");
				out.println("<td>"+cust.getFirstname()+"</td>");
				out.println("<td>"+cust.getLastname()+"</td>");
				out.println("<td>"+cust.getAddress()+"</td>");
				out.println("<td>"+cust.getGender()+"</td>");
				out.println("<td>"+cust.getRegdate()+"</td>");
				out.println("<td>"+cust.getRegfee()+"</td>");
				out.println("<td>"+cust.getCusttype()+"</td>");
				
				out.println("</tr>");
			}
				out.println("</table></body>");
	
				out.println("</html>");
			}
		}
		
		
		
	}


