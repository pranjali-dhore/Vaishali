package org.cap.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.model.Customer;
import org.cap.service.LoginService;
import org.cap.service.LoginServiceImpl;

/**
 * Servlet implementation class deleteCustomerServlet
 */
public class deleteCustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
LoginService loginService=new LoginServiceImpl();
		
		ArrayList<Customer> customers=loginService.getAllCustomers();
		
		
		PrintWriter out=response.getWriter();
		
		out.println("<html>");
		out.println("<head>ListAll Employee</head>"
				+ "<body>"
				+ "<table>"
				+ "<tr>"
				+ "<th>Employee Id</th>"
				+ "<th>FirstName</th>"
				+ "<th>LastName</th>"
				+ "<th>Address</th>"
				+ "<th>Gender</th>"
			
				+ "<th>Salary</th>"
				+ "<th>Date Of Birth</th>"
				+ "<th>Department</th>"
				+ "<th>Delete</th>"
				+ "</tr>");
		
			for(Customer cust:customers){
				out.println("<tr>");
				out.println("<td>"+cust.getCustid()+"</td>");
				out.println("<td>"+cust.getFirstname()+"</td>");
				out.println("<td>"+cust.getLastname()+"</td>");
				out.println("<td>"+cust.getAddress()+"</td>");
				out.println("<td>"+cust.getGender()+"</td>");
				out.println("<td>"+cust.getRegdate()+"</td>");
				out.println("<td>"+cust.getRegfee()+"</td>");
				out.println("<td>"+cust.getCusttype()+"</td>");
				out.println("<td><a href='DeleteCust?custid="+cust.getCustid()+"'>Delete</a></td>");
				
				out.println("</tr>");
			}
				out.println("</table></body>");
	
				out.println("</html>");
		
		
			}
	}


