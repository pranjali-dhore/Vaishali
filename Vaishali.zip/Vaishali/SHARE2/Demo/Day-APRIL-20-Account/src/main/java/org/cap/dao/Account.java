package org.cap.dao;

import java.util.Date;

public class Account {

	
	private int accountNo;
	private String accountName;
	private Date openDate;
	private String accountType;
	private double amount;
	private Date dateofbirth;
	private String gender;
	
	public Account(){}

	public Account(int accountNo, String accountName, Date openDate, String accountType, double amount,
			Date dateofbirth, String gender) {
		super();
		this.accountNo = accountNo;
		this.accountName = accountName;
		this.openDate = openDate;
		this.accountType = accountType;
		this.amount = amount;
		this.dateofbirth = dateofbirth;
		this.gender = gender;
	}

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public Date getOpenDate() {
		return openDate;
	}

	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public Date getDateofbirth() {
		return dateofbirth;
	}

	public void setDateofbirth(Date dateofbirth) {
		this.dateofbirth = dateofbirth;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", accountName=" + accountName + ", openDate=" + openDate
				+ ", accountType=" + accountType + ", amount=" + amount + ", dateofbirth=" + dateofbirth + ", gender="
				+ gender + "]";
	}
	
	
	
	
}
