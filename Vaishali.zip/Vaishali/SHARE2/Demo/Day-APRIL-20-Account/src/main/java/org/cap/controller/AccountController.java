package org.cap.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.cap.dao.Account;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AccountController {

	@RequestMapping("/hello")
	public ModelAndView sayHello()
	{
		return new ModelAndView("hello","message","Hello World!");
		
	}
	@RequestMapping("/accountForm")
	public String showAccountForm(Map<String, Object> maps)
	{
		List<String> accounts=new ArrayList<String>();
		
		accounts.add("Salary");
		accounts.add("Current");
		accounts.add("Loan");
		accounts.add("RD");
		accounts.add("FD");
		
		
		maps.put("account", new Account());
		maps.put("account",accounts);
		
		
		return "accountForm";
		
	}
	
	@RequestMapping(value="/showAccountDetails",method=RequestMethod.POST)
	public String showAccountDetails(@ModelAttribute("account") Account acc)
	{
		System.out.println(acc);
		return "showAccount";
	}
	}

