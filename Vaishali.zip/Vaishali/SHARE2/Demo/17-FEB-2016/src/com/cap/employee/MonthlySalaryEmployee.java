package com.cap.employee;

import java.util.Scanner;

public class MonthlySalaryEmployee extends Employee {

	int no_of_days;
	double salary_per_day,salary;
	@Override
	public void calculateSalary() {
	    
       Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter No.of Days=");
		no_of_days=sc.nextInt();
		
		System.out.println("Enter Salary per day=");
		salary_per_day=sc.nextDouble();
		
		salary=(no_of_days*salary_per_day);
		
		System.out.println("Weakly Salary Of Employee="+salary);
		
	}
	

}
