package com.cap.employee;

import java.util.Scanner;

public abstract class Employee {
	
  private int kinId;
	private String firstName,lastName;
	
	public  void getEmployee()
	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Kin Id=");
		kinId=sc.nextInt();
		
		System.out.println("Enter First Name=");
		firstName=sc.next();
		
		System.out.println("Enter Last Name=");
		lastName=sc.next();
	}
	public  void printEmployee()
	{
		System.out.println("Kin Id="+kinId+"\n"+"First Name="+firstName+"\n"+"Last Name="+lastName);
	}
	public abstract void calculateSalary();
	

}
