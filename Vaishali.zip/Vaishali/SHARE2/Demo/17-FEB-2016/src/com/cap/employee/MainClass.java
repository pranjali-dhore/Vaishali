package com.cap.employee;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		
		Employee employee=null;
		Scanner sc=new Scanner(System.in);
		int option;
	
		
		//WeaklySalaryEmployee w=new WeaklySalaryEmployee();
		//MonthlySalaryEmployee m=new MonthlySalaryEmployee();
		
		do
		{
		System.out.println("1.Weakly Salary of Employee");
		System.out.println("2.Monthly Salary of Employee");
		
		System.out.println("Enter Your Option=");
		option=sc.nextInt();
		
		if(option==1)
		    employee=new WeaklySalaryEmployee();
		else if(option==2)
			employee=new MonthlySalaryEmployee();
		else
			System.out.println("Invalid Option");
		}while(option!=1 && option!=2);
		
		employee.getEmployee();
		employee.printEmployee();
		employee.calculateSalary();

	}

}
