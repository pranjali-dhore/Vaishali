package com.cap.book;

import java.util.Scanner;

public class Book {
	
public int bookId;
	private String bookName,author,publisher;
	private double price;
	
	public Book getBookDetails()
	{
		Book book=new Book();
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Book Id=");
		book.bookId=sc.nextInt();
		
		System.out.println("Enter Book Name=");
		book.bookName=sc.next();
		
		System.out.println("Enter Book Author=");
		book.author=sc.next();
		
		System.out.println("Enter Book Publisher=");
		book.publisher=sc.next();
		
		System.out.println("Enter Price=");
		book.price=sc.nextDouble();
		
		
		return book;
		
	}
	
	public void showBookDetails()
	{
		System.out.println(bookId+"\t"+bookName+"\t"+author+"\t"+publisher+"\t"+price);
	}

}
