package com.cap.shape;

public class Shape {

	public void draw()
	{
		System.out.println("Shape Class Draw Method");
	}
}
