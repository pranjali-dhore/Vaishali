package com.cap.employee;

import java.util.Scanner;

public class WeaklySalaryEmployee extends Employee {
	int no_of_Hours;
	float wages_per_hour,salary;

	
	
	@Override
	public void calculateSalary() {
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter No.of Hours=");
		no_of_Hours=sc.nextInt();
		
		System.out.println("Enter Wages Per Hour=");
		wages_per_hour=sc.nextFloat();
		
		salary=(no_of_Hours*wages_per_hour);
		
		
		System.out.println("Weakly Salary Of Employee="+salary);
		
	}
	

}
