package com.cap.book;

public interface BookDAO {
	
	public void saveBook(Book book);
	public void listAllBooks();
	
	public void findBook(int bookId);
	public void deleteBook(int bookId);

}
