package com.cap.book;

import java.util.Scanner;

public class BookDAOImpl implements BookDAO {

	int index;
	Book[] booksRepository;
	
	public BookDAOImpl()
	{
		booksRepository=new Book[50];
	}
	@Override
	public void saveBook(Book book) {
	
		booksRepository[index]=book;
		index++;
		
				
	}

	@Override
	public void listAllBooks() {
		
		System.out.println("BookId\tBook Name\tAuthor\tPublisher\tPrice");
		for(int i=0;i<index;i++)
		{
			booksRepository[i].showBookDetails();
		}
	}
	@Override
	public void findBook(int bookId) {
		int temp=0;
		Book book;
		int i;
		for(i=0;i<index;i++)
		{
			if(booksRepository[i].bookId==bookId)
			{
				booksRepository[i].showBookDetails();
				break;
			}
		
		}
		
	}
	@Override
	public void deleteBook(int bookId) {
		int j=0,pos=0;
		for(int i=0;i<index;i++)
		{
			if(booksRepository[i].bookId==bookId)
			{
				 pos=i;
				break;
			}
		}
		for(j=pos;j<index;j++)
		{
			booksRepository[j]=booksRepository[j+1];
			
		}
		index--;
	}

	
	

}
