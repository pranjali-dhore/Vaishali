package com.cap.book;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		
		BookDAO bookdao=new BookDAOImpl();
		Book b1=new Book();
		int option;
		String choice;
		
		Scanner sc=new Scanner(System.in);
		
		do
		{
		System.out.println("1.Save Book");
		System.out.println("2.List All Books");
		System.out.println("3.Search Books");
		System.out.println("4.Delete Books");
		System.out.println("Enter Your Option=");
		option=sc.nextInt();
	
		if(option==1)
		{
			
			Book book=b1.getBookDetails();
			bookdao.saveBook(book);
		}
		else if(option==2)
		{
			
			bookdao.listAllBooks();
			
		}else if(option==3)
		{
			System.out.println("Enter Book Id");
			int bookId=sc.nextInt();
			bookdao.findBook(bookId);
		}
	
		else if(option==4)
		{
			System.out.println("Enter Book Id");
			int bookId=sc.nextInt();
			bookdao.deleteBook(bookId);
		}
		System.out.println("Do you want to continue?(y or N");
		choice=sc.next(); 
		}while((choice.charAt(0)=='y')|| (choice.charAt(0)=='Y'));
		
		
		
	
	}

}
