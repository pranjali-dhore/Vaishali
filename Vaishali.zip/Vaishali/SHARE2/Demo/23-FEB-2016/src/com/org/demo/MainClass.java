package com.org.demo;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
        boolean flag=false;
		SalaryValidatation  salary=new SalaryValidatation(); 
         Employee employee=new Employee();
         Scanner sc=new Scanner(System.in);
         System.out.println("Enter Salary=");
         double salary1=sc.nextDouble();
         flag=salary.isValidateSalary(salary1);
      
      try{
    	   if(!flag)
    	   {
                throw new InvalidSalaryException("Invalid Salary"); 
    	   }
       }catch(InvalidSalaryException ex)
       {
    	   System.out.println(ex.getMessage());
       }
         System.out.println(employee);
         

	}

}
