package com.org.accountdemo;

public interface AccountDAO {

	public void seeAccount(Account account);
	public void listAllAccount();
	 
}
