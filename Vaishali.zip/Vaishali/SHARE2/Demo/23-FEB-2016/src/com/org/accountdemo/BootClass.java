package com.org.accountdemo;

import java.util.Scanner;

public class BootClass {

	public static void main(String[] args) {

        UserInteraction user=new UserInteraction();
        Account account=new Account();
        Address address=new Address();
        
        Scanner sc=new Scanner(System.in);
        int option;
        String str;
        do
        {
        System.out.println("1.Save Account Details");
        System.out.println("2.Show Account Details");
        System.out.println("Enter your option=");
        option=sc.nextInt();
        if(option==1)
        {
          account=user.getAccountDetails();
          address=user.getAddress();
        }
        else if(option==2)
        {
          
                int accountId=account.getAccountId();
                  account=user.showAccountDetails(accountId);
                  System.out.println(account);
            
        }
        else
        {
        	System.out.println("Invalid option");
        }
        System.out.println("Do you want to continue y or n?");
        str=sc.next();
       }while(str.charAt(0)=='y' || str.charAt(0)=='Y');
        
       
        System.out.println(account);
       System.out.println(address);
	}

}
