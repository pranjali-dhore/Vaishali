package com.org.accountdemo;

import java.util.Date;

public class Account {

	     private int accountId;
	     private String accountName;
	     private String openDate;
	     private double balance;
	    
	     
	     public Account(){
	    	 
	     }

		public int getAccountId() {
			return accountId;
		}

		public void setAccountId(int accountId) {
			this.accountId = accountId;
		}

		public String getAccountName() {
			return accountName;
		}

		public void setAccountName(String accountName) {
			this.accountName = accountName;
		}

		public String getOpenDate() {
			return openDate;
		}

		public void setOpenDate(String openDate) {
			this.openDate = openDate;
		}

		public double getBalance() {
			return balance;
		}

		public void setBalance(double balance) {
			this.balance = balance;
		}

		

		

		@Override
		public String toString() {
			return "Account [accountId=" + accountId + ", accountName=" + accountName + ", openDate=" + openDate
					+ ", balance=" + balance +  "]";
		}
	     
		
}
