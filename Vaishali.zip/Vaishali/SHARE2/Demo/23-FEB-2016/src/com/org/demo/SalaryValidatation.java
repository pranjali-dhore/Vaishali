package com.org.demo;

public class SalaryValidatation {

	
	boolean flag=false;
	public  boolean isValidateSalary(double salary)
	{
		
	  
		if(salary>=2000 && salary<=50000)
		{
			flag=true;
		}

	
		return flag;
	
		
	}
}
