package com.org.accountdemo;

import java.util.Scanner;

public class UserInteraction {

	
	Scanner sc=new Scanner(System.in);
	public Account getAccountDetails()
	{
		Account account=new Account();
		
		//Account Id
	
		System.out.println("Enter Account Number=");
		int accountId=sc.nextInt();
		account.setAccountId(accountId);
		public void isValidAccountId()
		System.out.println("Enter Account Name=");
		String accountName=sc.next();
		account.setAccountName(accountName);
		
		System.out.println("Enter Open Date=");
		String openDate=sc.next();
		account.setOpenDate(openDate);
		
		System.out.println("Enter Balance=");
		double balance=sc.nextDouble();
		account.setBalance(balance);
		
		
		
		return account;
		
	}
	
	public Address getAddress()
	{
		//Address
				Address address=new Address();
				System.out.println("Enter Door No=");
				int doorNo=sc.nextInt();
				address.setDoorNo(doorNo);
				
				System.out.println("Enter Street Name=");
			     String streetName=sc.next();
				address.setStreetName(streetName);
				
				System.out.println("Enter city=");
				String city=sc.next();
				address.setCity(city);
				
				System.out.println("Enter State=");
				String state=sc.next();
				address.setState(state);
				
				System.out.println("Enter Pin Code=");
				int pincode=sc.nextInt();
				address.setPincode(pincode);
				
				return address;
				
	}
	
	public Account showAccountDetails(int accountId)
	{
		Account account=new Account();
		if(accountId==account.getAccountId())
		{
			
			System.out.println(account.getAccountId());
			System.out.println(account.getAccountName());
			System.out.println(account.getBalance());
			System.out.println(account.getOpenDate());
			
			
		}
		return account;
	}
}
