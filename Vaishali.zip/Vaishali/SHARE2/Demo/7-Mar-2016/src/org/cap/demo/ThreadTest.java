package org.cap.demo;

public class ThreadTest {

	public static void main(String[] args) throws InterruptedException {

		MyThread[] mt1=new MyThread[10];
		
		for(MyThread m:mt1)
		{
			m=new MyThread();
			m.start();
		}
	
		
	}

}
