package org.cap.demo1;

public class Table extends Thread{
	
	static int i=0;
	public void run()
	{
		
		for(;i<10;i++)
			System.out.println(Thread.currentThread().getName()+i);
	}

}
