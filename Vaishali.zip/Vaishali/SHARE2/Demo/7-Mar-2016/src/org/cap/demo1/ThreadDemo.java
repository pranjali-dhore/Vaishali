package org.cap.demo1;

public class ThreadDemo {

	public static void main(String[] args) {

       Table t1=new Table();
       Table t2=new Table();
       Table t3=new Table();
       Table t4=new Table();
       Table t5=new Table();
       t1.start();
       try {
   		t1.sleep(10);
   	} catch (InterruptedException e) {
   		// TODO Auto-generated catch block
   		e.printStackTrace();
   	}
       
       t2.start();
       try {
		t2.sleep(10);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
       t3.start();
       try {
   		t3.sleep(10);
   	} catch (InterruptedException e) {
   		// TODO Auto-generated catch block
   		e.printStackTrace();
   	}
       t4.start();
       t5.start();

	}

}
