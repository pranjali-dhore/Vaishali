package org.cap.demo;

public class MyThread extends Thread{
	
		static int i=0;
		
	
		public  void run()
		{
			print();
		}
		public  static void print()
		{
			for(;i<10;i++)
				synchronized(MyThread.class)
				{
			   System.out.println(Thread.currentThread().getName()+" "+"i="+i);
				}
		}
		}
	


