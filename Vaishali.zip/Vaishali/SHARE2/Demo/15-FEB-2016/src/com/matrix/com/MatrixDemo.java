package com.matrix.com;

import java.util.Scanner;

public class MatrixDemo {

	public static void main(String[] args) {
		 int[][] myArr=new int[2][2];
		   int[][] myArr1=new int[2][2];
		   int[][] mul=new int[2][2];
		   int sum=0,i,j,k,l,m;
		   Scanner sc=new Scanner(System.in);
		   System.out.println("Enter Array Elements For First Matrix=");
		   for( i=0;i<2;i++)
		   {
		     for(j=0;j<2;j++)
			 {
			     myArr[i][j]=sc.nextInt();
			 }
			}
			System.out.println("First Matrix Element");
			for(i=0;i<2;i++)
		   {
		     for(j=0;j<2;j++)
			 {
			    System.out.print(myArr[i][j]);
				System.out.print("\t");
				
			 }
			 System.out.println();
			}
			System.out.println("Enter Array Elements For Second Matrix=");
		   for(i=0;i<2;i++)
		   {
		     for(j=0;j<2;j++)
			 {
			     myArr1[i][j]=sc.nextInt();
			 }
			}
			System.out.println("Second Matrix Element");
			for(i=0;i<2;i++)
		   {
		     for(j=0;j<2;j++)
			 {
			    System.out.print(myArr1[i][j]);
				System.out.print("\t");
				
			 }
			 System.out.println();
			}
			System.out.println("Matrix Multiplication");
			for(k=0;k<myArr.length;k++)
			{
			    for(l=0;l<=k+1;l++)
				{
			    	for(m=0;m<=l;m++)
			    	{

					sum=((myArr[l][m]*myArr1[l][m])+(myArr[l][m+1]*myArr1[l+1][m]));
			    	}
			    	mul[l][m]=sum;
					System.out.print(mul[l][m]);
						System.out.print("\t");
				}
				
				
				 }
			
	}

}
