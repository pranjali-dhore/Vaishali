package org.rect.com;

public class MainClass {

	public static void main(String[] args) {
		Rectangle r1=new Rectangle();
		Rectangle r2=new Rectangle();
		r1.setLength(1);
		r1.setWidth(2);
		
		
		r2.setLength(1);
		r2.setWidth(2);
		
		
		
		if(r1.findArea()==r2.findArea() && r1.setColor("red")==r2.setColor("red"))
		{
			System.out.println("Both triangles are equal");
		}
		else
		{
			System.out.println("Not equal");
		}
	}

}
