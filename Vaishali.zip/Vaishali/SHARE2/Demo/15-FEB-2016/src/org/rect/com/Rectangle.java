package org.rect.com;

public class Rectangle {

	private double width,length,area;
	private String color;
	
	public void setLength(int l)
	{
		length=l;
		
	}
	public void setWidth(int w)
	{
		
		width=w;
		
	}
	public String setColor(String c)
	{
		
		color=c;
		return color;
	}
	public double findArea()
	{
		area=length*width;
		return area;
	}
}
