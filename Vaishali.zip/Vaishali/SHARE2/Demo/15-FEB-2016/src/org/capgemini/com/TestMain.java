package org.capgemini.com;

public class TestMain {

	public static void main(String[] args) {
		int[] myArr=null;
		
		SortArray sort=new SortArray();
		myArr=sort.getArrayElements(myArr);
		System.out.println("Before Sort");
		sort.printArrayElements(myArr);
		System.out.println("After Sort");
		sort.sortArrayElements(myArr);

	}

}
