package org.capgemini.com;

import java.util.Scanner;

public class SimpleInterest {

	double principle,int_rate,simpleInterest;
	float noofyears;
	Scanner sc=new Scanner(System.in);
	
		

	public void findInterest() {
		simpleInterest=(double)((principle*noofyears*int_rate)/100);
		System.out.println("Simple Interest="+simpleInterest);
	}



	public void getInput() {
		System.out.println("Enter Principle=");
		principle=sc.nextDouble();
		
		System.out.println("Enter No. of years=");
		noofyears=sc.nextFloat();
		
		System.out.println("Enter interest rate=");
		int_rate=sc.nextDouble();
	}
}
