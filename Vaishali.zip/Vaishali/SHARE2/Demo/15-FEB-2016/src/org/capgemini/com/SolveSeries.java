package org.capgemini.com;

import java.util.Scanner;
public class SolveSeries {

	public int num;
	public double sum;
	 
	
	Scanner sc=new Scanner(System.in);
	
	public void getInput()
	{
		System.out.println("Enter Number=");
		num=sc.nextInt();
	
	}
	
	public long findFactorial(int num)
	{
		int i;
		long fact=1;
		for(i=num;i>0;i--)
		{
		   fact=fact*i;
		 
		}
		return fact;
	}
	
	public long findPower(int base,int power)
	{
		long value=1;
		while(power!=0)
		{
			value=value*base;
			power--;
		}
		return value;
	}
	public double sumOfSeries()
	{
		
		for(int i=0;i<=num;i++)
		{
			
			sum=(double)findPower(i,i)/findFactorial(i);
		}
		return sum;
		
	}
}
