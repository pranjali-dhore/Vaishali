package org.capgemini.com;

public class mainClass {

	public static void main(String[] args) {
	
		 Person p=new Person();
		 p.getPersonDetails();
		 p.printPersonDetails();
		 p.calculateAvg();

	}

}
