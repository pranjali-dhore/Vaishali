package org.capgemini.com;

import java.util.Scanner;
public class Person {
	
	private int personId;
	public String personName,address;
	public int java,c,sql;
	public Double average;
	
	Scanner sc=new Scanner(System.in);
	
	public void getPersonDetails()
	{
		System.out.println("Enter Id=");
		personId=sc.nextInt();
		
		System.out.println("Enter Name=");
		personName=sc.next();
		
		System.out.println("Enter Address=");
		address=sc.next();
		
		System.out.println("Enter Marks of Java=");
		java=sc.nextInt();
		
		System.out.println("Enter Marks of C=");
		c=sc.nextInt();
		
		System.out.println("Enter Marks of SQL=");
		sql=sc.nextInt();
		
		
	}
	
	public void printPersonDetails()
	{
		System.out.println("Person Id="+personId);
		System.out.println("Person Name="+personName);
		System.out.println("Address="+address);
		System.out.println("Marks of Java="+java);
		System.out.println("Marks of C="+c);
		System.out.println("Marks of SQL="+sql);
		
	}
	
	public void calculateAvg()
	{
		System.out.println("Average="+((java+c+sql)/3));
	}
}
