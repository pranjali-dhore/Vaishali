package org.capgemini.com;

import java.util.Scanner;

public class SortArray {

	int[] myArray;
	public int size;
	
	public int[] initializeArray(int size,int[]myArray)
	{
		myArray=new int[size];
		return myArray;
	}
	
	public int[] getArrayElements(int[]myArray)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("What is size of Array");
		size=sc.nextInt();
		
		myArray=initializeArray(size,myArray);
		
		System.out.println("Array Elements=");
		
		for(int i=0;i<myArray.length;i++)
		{
			myArray[i]=sc.nextInt();
			
		}
       return myArray;
     
	}
	
	public void printArrayElements(int[] myArray)
	{
		 for(int i=0;i<myArray.length;i++)
		 {
			 System.out.print(myArray[i]+" ");
		 }
		 System.out.println();
	}
	
	

	public void sortArrayElements(int[] myArr) {
		initializeArray(size,myArr);
		for(int i=size-1;i>=0;i++)
		{
			
			System.out.print(myArray[i]+" ");
		}
		System.out.println();
	
		 
	}
}

