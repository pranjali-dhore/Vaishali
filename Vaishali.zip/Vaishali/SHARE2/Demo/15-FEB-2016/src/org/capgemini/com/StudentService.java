package org.capgemini.com;

import java.util.Scanner;

public class StudentService {

	Student[] students;
	
	public void initializeArray(int size)
	{
		students=new Student[size];
		
	}
	
	
	public void getStudents() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter how many Students=");
		int size=sc.nextInt();
		
		initializeArray(size);
		
		for(int i=0;i<size;i++)
		{
		 students[i]=new Student();
			students[i].getStudentDetails();
		}
		
	}
	public void sortByFees(){

		
		
			for(int i=0;i<students.length-1;i++)
			{
				for(int j=i+1;j<students.length-1;j++)
				{ 
					
					if(students[i].getFees()>students[j].getFees())
					{
						Student temp=students[i];
						students[i]=students[j];
						students[j]=temp;
						
					}
				}
				
			}
			
			System.out.println("Student Id \t First Name \t Last Name \t Fees");
			for(int i=0;i<students.length;i++)
			{
				
				System.out.println(students[i].studId+"\t"+students[i].firstName+"\t"+students[i].lastName+"\t"+students[i].fees);
			}
			
	}
	
		
		
	
	public void printStudents() {
		System.out.println("Student Id \t First Name \t Last Name \t Fees");
		for(int i=0;i<students.length;i++)
		{
			students[i].printStudentDetails();
		}
		
	}
}
	