package org.capgemini.com;

public class mainMethod {

	public static void main(String[] args) {
		SolveSeries s=new SolveSeries();
		s.getInput();
		System.out.println("Sum of the series="+s.sumOfSeries());
		
	    

	}

}
