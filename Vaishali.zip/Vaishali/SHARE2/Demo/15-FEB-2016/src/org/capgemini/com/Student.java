package org.capgemini.com;

import java.util.Scanner;

public class Student {
	
public int studId;
	public String firstName,lastName;
public float fees;
	
	public void getStudentDetails()
	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Student Id=");
		studId=sc.nextInt();
		
		System.out.println("Enter First Name=");
		firstName=sc.next();
		
		System.out.println("Enter Last Name=");
		lastName=sc.next();
		
		System.out.println("Enter Fees=");
		fees=sc.nextFloat();
		
	}
	public float getFees()
	{
		return fees;
	}
	
	public void printStudentDetails()
	{
		System.out.println(studId+"\t"+firstName+"\t"+lastName+"\t"+fees);
		
	}
	
	

}
