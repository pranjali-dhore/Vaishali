package org.capgemini.com;

public class TestStud {

	public static void main(String[] args) {
		StudentService stud=new StudentService();
		
		stud.getStudents();
		//stud.printStudents();
		System.out.println("After Sort");
		stud.sortByFees();

	}

}
