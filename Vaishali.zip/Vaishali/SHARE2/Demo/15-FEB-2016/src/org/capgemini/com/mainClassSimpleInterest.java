package org.capgemini.com;

public class mainClassSimpleInterest {

	public static void main(String[] args) {

      SimpleInterest simpleinterest=new SimpleInterest();
      simpleinterest.getInput();
      simpleinterest.findInterest();

	}

}
