package org.stack.com;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {

      StackDemo stack=new StackDemo();
     
      System.out.println("Enter elements for first stack=");
    
      for(int i=1;i<10;i++)
      {
    	  Scanner sc=new Scanner(System.in);
    	  int num=sc.nextInt();
    	  stack.push(num);
      }
     
      System.out.println("After Push");
      stack.printElements();
      
    /* System.out.println("After Pop");
     for(int i=0;i<10;i++) 
     {
      stack.pop();
      
     }*/
      
    StackDemo stack2=new StackDemo();
     System.out.println("Enter elements for second stack=");
     
     for(int i=1;i<10;i++)
     {
   	  Scanner sc=new Scanner(System.in);
   	  int num=sc.nextInt();
   	  stack2.push(num);
     }
     System.out.println("After Push");
     stack2.printElements();
    /*System.out.println("After Pop");
     for(int i=0;i<10;i++) 
    {
     stack2.pop();
     
    }*/
     
     if(stack.pop()==stack2.pop())
     {
        System.out.println("Both Stacks are equal");
	}
     else
     {
    	 System.out.println("Both Stacks are not equal");
     }
	}
}
