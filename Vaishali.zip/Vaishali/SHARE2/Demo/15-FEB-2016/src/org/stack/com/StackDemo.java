package org.stack.com;

import java.util.Scanner;
public class StackDemo {
	
	int top=-1,num;
	public int SIZE=10;
	int[] array=new int[SIZE];
	
	
	public void push(int num)
	{
		
		
		if(top==SIZE-1)
		{
			System.out.println("Stack is overflow");
		}
		else
		{
			top=top+1;
			array[top]=num;
		}
		
	
		}
		
	
	
	public int pop()
	{
		if(top<0)
		{
			System.out.println("Stack is Underflow");
		}
		else
		{
			top--;
		}
		int popEle=top;
		return popEle;
		//System.out.println(popEle);
		
	}

	public void printElements()
	{
		if(top>=0)
		{
			for(int i=0;i<=top;i++)
			{
				System.out.println(array[i]);
			}
		}
	}
	
}
