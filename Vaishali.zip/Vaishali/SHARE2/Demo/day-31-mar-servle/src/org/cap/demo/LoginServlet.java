package org.cap.demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String uname=request.getParameter("uname");
		String pass=request.getParameter("pwd");
		boolean flag=false;
		
		String uname1=null,pass1=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		
		Connection con=null;
		con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/login","root","Pass1234");
		Statement stmt;
		stmt=(Statement) con.createStatement();
		
		String str="select firstname,city from student";
		ResultSet rs=stmt.executeQuery(str);
		
		while(rs.next())
		{
		
		uname1=rs.getString(1);
		pass1=rs.getString(2);
		
		
		
		if(uname.equals(uname1) && pass.equals(pass1))
		{
			flag=true;
			response.sendRedirect("pages/success.html");
			break;
		}
		
		
			
		
		}
		if(flag==false)
			response.sendRedirect("pages/login.html");
		
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
