package com.org.demo1;



class MyRunnable implements Runnable
{
MyRunnable(String name)
{
new Thread(this, name).start();
}
public void run()
{
System.out.println(Thread.currentThread().getName());
}
}
