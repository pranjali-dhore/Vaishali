package com.org.pojoclass;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import com.org.employee.Validation;

public class UserInteraction {

	       
	public Employee getEmployeeDetails()
	{
		Employee employee=new Employee();
		Scanner sc=new Scanner(System.in);
		boolean flag;
		int empId;
		String kinId,lastName,firstName,address,email,mobileNo;
		Date dob;
		//Employee Id
		do
		{
			System.out.println("Enter Employee Id=");
			empId=sc.nextInt();
			
			flag=Validation.isValidempId(empId);
			if(flag==false)
			{
				System.out.println("Invalid Employee Id please try again");
			}
			else
				System.out.println("Valid Employee Id");
		}while(flag==false);
		employee.setEmpId(empId);
	
	//Kin Id
	do
	{
		System.out.println("Enter Kin Id=");
		 kinId=sc.next();
		
		flag=Validation.isValidKinid(kinId);
		if(!flag)
		{
			System.out.println("Invalid Kin Id please try again");
		}
		else
			System.out.println("Valid Kin Id");
	}while(!flag);
	employee.setKinId(kinId);
	
	//Employee Name
	
	do
	{
		System.out.println("Enter First Name=");
		firstName=sc.next();
		
		flag=Validation.isValidempName(firstName);
		if(!flag)
		{
			System.out.println("Invalid First Name please try again");
		}
		else
			System.out.println("Valid Name");
	}while(!flag);
	employee.setFirstName(firstName);
	//Last Name
	do
	{
		System.out.println("Enter Last Name=");
		lastName=sc.next();
		
		flag=Validation.isValidlastName(lastName);
		if(!flag)
		{
			System.out.println("Invalid Last Name please try again");
		}
		else
			System.out.println("Valid Last Name");
	}while(!flag);
	employee.setLastName(lastName);
	//Address
	
	do
	{
		System.out.println("Enter Address=");
		address=sc.next();
		
		flag=Validation.isValidAddress(address);
		if(!flag)
		{
			System.out.println("Invalid address please try again");
		}
		else
			System.out.println("Valid Address");
	}while(!flag);
	
	//Email Id
	
	do
	{
		System.out.println("Enter Email Id=");
		email=sc.next();
		
		flag=Validation.isValidEmail(email);
		if(!flag)
		{
			System.out.println("Invalid Email Id please try again");
		}
		else
			System.out.println("Valid Email Id");
	}while(!flag);
	
	//Mobile Number
	
	do
	{
		System.out.println("Enter Mobile Number=");
		 mobileNo=sc.next();
		
		flag=Validation.isValidMobileNo(mobileNo);
		if(!flag)
		{
			System.out.println("Invalid Mobile please try again");
		}
		else
			System.out.println("Valid Mobile Number");
	}while(!flag);
	employee.setMobileNo(mobileNo);
	
	
	//Date Of birth
	
	

	String edob;
	do{
		System.out.println("Enter Employee Date of Birth[dd-MMM-yyyy]:");
		edob=sc.next();
		flag=Validation.isValidDate(edob);
			if(!flag)
				System.out.println("Please enter Valid Date!");
			
	}while(!flag);
	Date empDob=new Date(edob);
	employee.setDob(empDob);

	
	String doj;
	do
	{
		System.out.println("Enter Employee Date of Joining[dd-MMM-yyyy]:");
		doj=sc.next();
		flag=Validation.isValidDate(doj);
			if(!flag)
				System.out.println("Please enter Valid Date!");
			
	}while(!flag);
	Date empDob1=new Date(edob);
	employee.setDob(empDob1);
	
	
	return employee;
	}
	
	
}
