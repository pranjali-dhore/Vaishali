package com.org.employee;

public class MainClass {

	public static void main(String[] args) {
		Employee emp=new Employee();
		emp.getEmployeeDetails();

	}

}
