package com.org.employee;

import java.util.Date;

public class Validation {
	
	public static boolean isValidempId(int empId){
		boolean flag=false;
		if(empId>=1000 && empId<=9999)
		    flag=true;
		return flag;		  
	}
	public static boolean isValidKinid(String kinId){
		return kinId.matches("\\d{5}_[F|I|T][S]");
	}

	public static boolean isValidempName(String firstName){
		return firstName.matches("\\w[A-Za-z]+");
	}
	
	public static boolean isValidlastName(String lastName){
		return lastName.matches("\\w[A-Za-z]+");
	}
	
	public static boolean isValidAddress(String address){
		return address.matches("\\w[-A-Za-z]-][#][/][,]");
	}
	
	public static boolean isValidEmail(String email){
		return email.matches("\\w[a-z]\\[@] a-z . a-z]");
	}

	public static boolean isValidMobileNo(String mobileNo){
		return mobileNo.matches("\\d{10}");
	}
	public static boolean isValidDate(String myDate) {
		return myDate.matches("[123]\\d{1}-(jan|feb|mar|apr|jun|jul|aug|sep|oct|dec)-"
				+ "[12][890]\\d{2}");
		
	}
	
	
}
