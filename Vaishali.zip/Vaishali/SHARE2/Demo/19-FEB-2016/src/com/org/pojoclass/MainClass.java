package com.org.pojoclass;

public class MainClass {

	public static void main(String[] args) {
		UserInteraction user=new UserInteraction();
		Employee emp=user.getEmployeeDetails();
        System.out.println(emp);
	}

}
