package com.org.datedemo;

public class MainClass {

	public static void main(String[] args) {

      Person p=new Person();
       p.getData();
       p.calculateAge();

	}

}
