package com.org.datedemo;

import java.util.Date;
import java.util.Scanner;

public class Person  {

           String dateofbirth;
	
      public void getData()
      {
         
         Scanner sc=new Scanner(System.in);
         System.out.println("Enter Date Of Birth=");
         dateofbirth=sc.nextLine();
              
         }
      
      public void calculateAge()
      {
       
    	  Date todaydate=new Date();
    	 System.out.println(todaydate);
    	
		Date mydate=new Date(dateofbirth);
    	 
    	 
    	  
    	 int day=todaydate.getDay()-mydate.getDay();
    	  int month=(todaydate.getMonth())-(mydate.getMonth());
    	  int year=(todaydate.getYear()-1900)-(mydate.getYear()-1900);
    	  System.out.println(todaydate.getYear());
    	  System.out.println(todaydate.getMonth());
    	  System.out.println(todaydate.getDay());
    	  System.out.println("Age="+year+"year"+month+"month"+day+"days");
    	  
    	  
    	  
      }

}
