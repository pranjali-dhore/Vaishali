package org.com.FilmPojo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
@Entity
public class FilmCategory {
	
	//private fields
	@Id
		private int category_Id;
		private String category_Name;
		

		@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY,
				targetEntity=FilmPojo.class,mappedBy="category")
		private List<FilmPojo> films=new ArrayList<FilmPojo>();
		
		public FilmCategory(){}

		public FilmCategory(int category_Id, String category_Name) {
			super();
			this.category_Id = category_Id;
			this.category_Name = category_Name;
		}
		
		public FilmCategory(int category_Id, String category_Name,List<FilmPojo> films) {
			super();
			this.category_Id = category_Id;
			this.category_Name = category_Name;
			this.films=films;
		}


		public int getCategory_Id() {
			return category_Id;
		}

		public void setCategory_Id(int category_Id) {
			this.category_Id = category_Id;
		}

		public String getCategory_Name() {
			return category_Name;
		}

		public void setCategory_Name(String category_Name) {
			this.category_Name = category_Name;
		}

		@Override
		public String toString() {
			return "FilmCategory [category_Id=" + category_Id + ", category_Name=" + category_Name + "]";
		}
		
		

}
