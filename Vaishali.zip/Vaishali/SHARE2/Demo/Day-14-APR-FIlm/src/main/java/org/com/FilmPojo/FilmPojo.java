package org.com.FilmPojo;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
@Entity
public class FilmPojo {
	
	@Id
	//private fields
	@GeneratedValue
		private int film_Id;
		private String descreption;
		private String film_Title;
	   // private Date release_Year;
		//private List<LanguageFilm> languages;
		//private LanguageFilm original_Language;
		//private Date rental_Duration;
		private int length;
		private double replacement_Cost;
		private int ratings;
		private String special_Features;
		//private List<ActorFilm> actors;
		@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
		@JoinColumn(name="category_Id_FK")
		private FilmCategory category;
		
		public FilmPojo(){}

		public FilmPojo(String descreption, String film_Title,int length,
				double replacement_Cost, int ratings, String special_Features,FilmCategory category) {
			super();
			//this.film_Id = film_Id;
			this.descreption = descreption;
			this.film_Title = film_Title;
			//this.release_Year = release_Year;
			//this.languages = languages;
			//this.original_Language = original_Language;
			//this.rental_Duration = rental_Duration;
			this.length = length;
			this.replacement_Cost = replacement_Cost;
			this.ratings = ratings;
			this.special_Features = special_Features;
			//this.actors = actors;
			//this.category = category;
			this.category=category;
		}
		
		
		public FilmPojo(int film_Id, String descreption, String film_Title,int length,
				double replacement_Cost, int ratings, String special_Features,FilmCategory category) {
			super();
			this.film_Id = film_Id;
			this.descreption = descreption;
			this.film_Title = film_Title;
			//this.release_Year = release_Year;
			//this.languages = languages;
			//this.original_Language = original_Language;
			//this.rental_Duration = rental_Duration;
			this.length = length;
			this.replacement_Cost = replacement_Cost;
			this.ratings = ratings;
			this.special_Features = special_Features;
			//this.actors = actors;
			this.category = category;
		}
		
		

		public int getFilm_Id() {
			return film_Id;
		}

		public void setFilm_Id(int film_Id) {
			this.film_Id = film_Id;
		}

		public String getDescreption() {
			return descreption;
		}

		public void setDescreption(String descreption) {
			this.descreption = descreption;
		}

		public String getFilm_Title() {
			return film_Title;
		}

		public void setFilm_Title(String film_Title) {
			this.film_Title = film_Title;
		}

		/*public Date getRelease_Year() {
			return release_Year;
		}

		public void setRelease_Year(Date release_Year) {
			this.release_Year = release_Year;
		}

		public List<LanguageFilm> getLanguages() {
			return languages;
		}

		public void setLanguages(List<LanguageFilm> languages) {
			this.languages = languages;
		}

		public LanguageFilm getOriginal_Language() {
			return original_Language;
		}

		public void setOriginal_Language(LanguageFilm original_Language) {
			this.original_Language = original_Language;
		}

		public Date getRental_Duration() {
			return rental_Duration;
		}

		public void setRental_Duration(Date rental_Duration) {
			this.rental_Duration = rental_Duration;
		}
*/
		public int getLength() {
			return length;
		}

		public void setLength(int length) {
			this.length = length;
		}

		public double getReplacement_Cost() {
			return replacement_Cost;
		}

		public void setReplacement_Cost(double replacement_Cost) {
			this.replacement_Cost = replacement_Cost;
		}

		public int getRatings() {
			return ratings;
		}

		public void setRatings(int ratings) {
			this.ratings = ratings;
		}

		public String getSpecial_Features() {
			return special_Features;
		}

		public void setSpecial_Features(String special_Features) {
			this.special_Features = special_Features;
		}

	/*	public List<ActorFilm> getActors() {
			return actors;
		}

		public void setActors(List<ActorFilm> actors) {
			this.actors = actors;
		}
*/
		public FilmCategory getCategory() {
			return category;
		}

		public void setCategory(FilmCategory category) {
			this.category = category;
		}

		@Override
		public String toString() {
			return "FilmPojo [film_Id=" + film_Id + ", descreption=" + descreption + ", film_Title=" + film_Title
					+ ", length=" + length + ", replacement_Cost=" + replacement_Cost + ", ratings=" + ratings
					+ ", special_Features=" + special_Features + ", category=" + category + "]";
		}

		
		
		
		
		

}
