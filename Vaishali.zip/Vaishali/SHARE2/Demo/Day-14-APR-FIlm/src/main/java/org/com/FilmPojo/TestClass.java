package org.com.FilmPojo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class TestClass {

	public static void main(String[] args) {
		
		
		AnnotationConfiguration config=new AnnotationConfiguration();
		config.addAnnotatedClass(FilmPojo.class);
		config.addAnnotatedClass(FilmCategory.class);
		config.configure();
		
		new SchemaExport(config).create(true, true);
		
		SessionFactory factory= config.buildSessionFactory();
		Session session=factory.openSession();
		session.beginTransaction();
		
		
		FilmCategory cat=new FilmCategory(1,"Comedy");
		FilmCategory cat1=new FilmCategory(2,"Romantic");
		
		FilmPojo fp=new FilmPojo("good","Sanam Re",200,500,2,"very nice",cat);
		
		FilmPojo fp1=new FilmPojo("goodjgkh","Sanam Teri kasam",100,600,3,"very good  nice",cat1);
		
		session.save(fp);
		session.save(fp1);
		
session.getTransaction().commit();
		
		session.close();
		
	}

}
