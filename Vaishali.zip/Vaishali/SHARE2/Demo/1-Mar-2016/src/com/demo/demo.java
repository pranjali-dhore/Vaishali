package com.demo;

public class demo {

	public static void main(String[] args) {
		String str="Hello";
		System.out.println(str.charAt(9));

	}

}
