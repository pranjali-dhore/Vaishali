package org.cap.demo;

public class Circle<T,U> {

	private T obj;
	private U obj1;
	public Circle(T obj,U obj1)
	{
		this.obj=obj;
		this.obj1=obj1;
		
	}
	public void showInfo()
	{
		System.out.println("T--->"+obj+obj.getClass().getName());
		System.out.println("U--->"+obj1+obj1.getClass().getName());
	}
	
}
