package org.cap.demo;

public class Y implements InterA{
	public void show()
	{
		System.out.println("Y class method");
	}
}
