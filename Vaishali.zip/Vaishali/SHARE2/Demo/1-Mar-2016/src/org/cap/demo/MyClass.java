package org.cap.demo;

public class MyClass <T extends InterA>{

	private T obj;
	
	public MyClass(T obj)
	{
		this.obj=obj;
		
	}
	public void show()
	{
		System.out.println(obj.getClass().getName());
		obj.show();
	}
}
