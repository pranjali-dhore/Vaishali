package org.cap.demo;

public class X implements InterA{

	public void show()
	{
		System.out.println("X class method");
	}
}
