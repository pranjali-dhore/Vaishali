package org.cap.demo;

public class MainClass {

	public static void main(String[] args) {
	//Circle<Integer,String> circle=new Circle<Integer,String>(23,"Tom");
      //circle.showInfo();
		
		MyClass<InterA> objA=new MyClass<InterA>(new X());
		MyClass<InterA> objB=new MyClass<InterA>(new Y());
		
		objA.show();
		objB.show();
		}

}
