package org.cap.demo;

public interface InterA {

	public void show();
}
