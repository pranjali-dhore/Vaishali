package org.com.generics;

public class MainClass {

	public static void main(String[] args) {

    EmployeeUtil<CGEmployee> cg=new EmployeeUtil<CGEmployee>(new CGEmployee("Tom",5000));
    EmployeeUtil<CTSEmployee> cts=new EmployeeUtil<CTSEmployee>(new CTSEmployee("Jerry",6000));
  
    
    cg.show();
    cts.show();
    
    cg.compareSalary(cts);
	}

}
