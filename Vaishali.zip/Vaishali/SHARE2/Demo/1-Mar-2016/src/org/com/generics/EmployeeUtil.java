package org.com.generics;

public class EmployeeUtil <T extends Employee>{
	
	private T empObj;

	public T getempObj(){
		return empObj;
	}
	
	public EmployeeUtil(T empObj)
	{
		this.empObj=empObj;
	}
	public void show()
	{
		System.out.println(empObj.getClass().getName());
	}
	
	public void compareSalary(EmployeeUtil<?>emp)
	{
		if(empObj.getSalary()==emp.getempObj().getSalary())
		{
			System.out.println("Equal");
		}
		else
			System.out.println(" Not Equal");
	}

}
