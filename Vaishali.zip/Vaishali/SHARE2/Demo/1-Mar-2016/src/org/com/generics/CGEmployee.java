package org.com.generics;

public class CGEmployee extends Employee{

	public CGEmployee(String ename,double salary){
		super(ename,salary);
	}

	
}
