package com.org.conn;

import java.sql.DriverManager;
import java.sql.ResultSet;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

public class RetrivingDataDb {

	public static void main(String[] args) throws Exception{
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=null;
		con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/stud","root","Pass1234");
		Statement stmt;
		stmt=(Statement) con.createStatement();
		String str="select rollno,firstname,lastname from student";
		ResultSet rs=stmt.executeQuery(str);
		System.out.print("RollNo"+"\t"+"FirstName"+"\t"+"LastName");
		System.out.println(" ");
		while(rs.next())
		{
			int rollno=Integer.parseInt(rs.getString(1));
			System.out.println(rollno+"\t"+rs.getString(2)+"\t\t"+rs.getString(3));
		}
		con.close();

	}

}
