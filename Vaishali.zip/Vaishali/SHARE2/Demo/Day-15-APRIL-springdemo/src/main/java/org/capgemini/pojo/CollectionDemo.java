package org.capgemini.pojo;

import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class CollectionDemo {

private Set<Address> names;
	
	private Map<Integer, String> maps;
	
	
	private Properties properties;
	
	
	public CollectionDemo(){}


	public CollectionDemo(Set<Address> names, Map<Integer, String> maps, Properties properties) {
		super();
		this.names = names;
		this.maps = maps;
		this.properties = properties;
	}


	public Set<Address> getNames() {
		return names;
	}


	public void setNames(Set<Address> names) {
		this.names = names;
	}


	public Map<Integer, String> getMaps() {
		return maps;
	}


	public void setMaps(Map<Integer, String> maps) {
		this.maps = maps;
	}


	public Properties getProperties() {
		return properties;
	}


	public void setProperties(Properties properties) {
		this.properties = properties;
	}
	
	
}
