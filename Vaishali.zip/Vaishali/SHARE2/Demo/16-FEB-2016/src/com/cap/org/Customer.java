package com.cap.org;

import java.util.Scanner;

public class Customer {
	
	private int custId;
	private String custName;
	private double fees;
	Address address=new Address();
	
	public Customer()
	{
	   this.custId=0;
	   this.custName="abc";
	   this.fees=200000;
	   
	}

	public Customer(int custId,String custName,double fees,Address address)
	{
		
	   this.custId=custId;
	   this.custName=custName;
	   this.fees=fees;
	   this.address=address;
	}
	
	public void getCustomer()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Customer Id=");
		custId=sc.nextInt();
		
		System.out.println("Enter Customer Name=");
		custName=sc.next();

		
		System.out.println("Enter Fees=");
		fees=sc.nextDouble();
		
		address=new Address();
		address.getAddress();
		
	}
	
	public void printCustomer()
	{
		System.out.println("Customer Id="+custId+"\n"+"Customer Name="+custName+"\n"+"Fees="+fees+"\n"+"Address="+address);
		
	}
}
