package com.cap.org;

import java.util.Scanner;

public class Address {
	
	public int doorNo,pincode;
	public String state,city;
	private Address address;
	
	public Address()
	{
		this.doorNo=1;
		this.city="Delhi";
		this.pincode=123456;
		this.state="Maha";
	}
	
	public Address(int doorNo,String city,int pincode,String state)
	{
		this.doorNo=doorNo;
		this.city=city;
		this.pincode=pincode;
		this.state=state;
	}
	
	public void getAddress()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter DoorNo=");
		doorNo=sc.nextInt();
		
		System.out.println("Enter City=");
		city=sc.next();
		
		System.out.println("Enter Pincode=");
		pincode=sc.nextInt();
		
		System.out.println("Enter State=");
		state=sc.next();
	}
	
	public void printAddress()
	{
		System.out.println("DoorNo="+doorNo+"\n"+"City="+city+"\n"+"Pincode="+pincode+"\n"+"State="+state);
		
	}

}
