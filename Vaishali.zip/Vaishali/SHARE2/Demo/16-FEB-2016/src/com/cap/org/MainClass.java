package com.cap.org;

public class MainClass {

	public static void main(String[] args) {
		Customer c1=new Customer();
		
		Customer c2=new Customer(1,"Vaishu",200,null);
		
		
		Address a1=new Address();
		Address a2=new Address(20,"pune",413115,"karnataka");
		
		c1.getCustomer();
		a1.getAddress();
		c1.printCustomer();
		a1.printAddress();
		
		

	}

}
