package com.cg.demo1;

import com.cg.demo.LeapYear;

import static org.junit.Assert.*;
import junit.framework.TestCase;

public class FindLeapYear extends TestCase {
	
	/* 1.Year is divisible by 4.
	 * 2.Year is not divisible by 4.
	 * 3.Year is divisible by 100 not divisible by 400.
	 * 4.Year is not divisible by 100  divisible by 400.
	 * 4.Negative numbers are not year.
	 */
 
	public void testYearIsDivisibleByFour()
	{
		LeapYear ly=new LeapYear();
		assertTrue(ly.isLeapYear(2016));
		
	}

	public void testYearIsNotDivisibleByFour()
	{
		LeapYear ly=new LeapYear();
		assertFalse(ly.isLeapYear(2017));
		
	}
 
	public void testYearIsDivisibleByHundred()
	{
		LeapYear ly=new LeapYear();
		assertTrue(ly.isLeapYear(2016));
		
	}
	/*public void testYearIsDivisibleNotByHundred()
	{
		LeapYear ly=new LeapYear();
		assertFalse(ly.isLeapYear(2017));
		
	}
	
	public void testYearIsDivisibleByFourHundred()
	{
		LeapYear ly=new LeapYear();
		assertTrue(ly.isLeapYear(2016));
		
	}*/

	public void testYearIsDivisibleByNotFourHundred()
	{
		LeapYear ly=new LeapYear();
		assertFalse(ly.isLeapYear(2017));
		
	}
   @Test(expected=java.lang.RuntimeException.class)
	public void testNegativeNumberIsNotYear()
	{
		LeapYear ly=new LeapYear();
		assertFalse(ly.isLeapYear(2017));
		
	}
	
	
}
