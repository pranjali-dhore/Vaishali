package com.cg.demo;

public class LeapYear {
	
	boolean flag=false;
	public boolean isLeapYear(int year)
	{
		if(year<0)
			throw new RuntimeException();
			flag=false;
		
		if(year%4==0||year%100==0 && year%400==0)
			
			   flag=true;
		else
			flag=false;
		return flag;
	}

}
