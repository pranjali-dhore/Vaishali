package com.cg.demo1;

public @interface Test {

	Class<RuntimeException> expected();

}
