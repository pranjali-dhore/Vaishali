package com.org.jdemo;

import junit.framework.TestCase;

public class test extends TestCase {

}
