package com.org.jdemo;

public @interface Test1 {

}
