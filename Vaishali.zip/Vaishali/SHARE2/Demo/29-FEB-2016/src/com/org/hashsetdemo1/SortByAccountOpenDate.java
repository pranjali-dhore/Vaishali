package com.org.hashsetdemo1;

import java.util.Comparator;

public class SortByAccountOpenDate implements Comparator<Account>{

	@Override
	public int compare(Account account1, Account account2) {
		
		//if(account1.getOpenDate()>account2.)
		return 0;
	}

}
