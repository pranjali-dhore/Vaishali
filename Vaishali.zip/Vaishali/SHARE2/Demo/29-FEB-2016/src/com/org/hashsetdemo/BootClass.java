package com.org.hashsetdemo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.TreeSet;

public class BootClass {

	public static void main(String[] args) {

		
         ArrayList<Employee> emp=new ArrayList<>();
     
         
         emp.add(new Employee(1,"Tom","jerry",50990));
         emp.add(new Employee(2,"Ram","patil",60990));
         emp.add(new Employee(1,"Tom","jerry",50990));
        emp.add(new Employee(3,"Jack","jerry",70990));
       //emp.add(new Employee(6,null,null,3333));
         
     
         String str;
         Scanner sc=new Scanner(System.in);
         do
         {
         System.out.println("1.Sort by employee id");
         System.out.println("2.Sort by first name");
         System.out.println("3.Sort by last name");
         System.out.println("4.Sort by salary");
         System.out.println("Enter option=");
         int option=sc.nextInt();
         if(option==1)
         {
        	 Collections.sort(emp);
        	 for(Employee employee1:emp)
             {
            	 System.out.println(employee1);
             }
         }
         else if(option==2)
         {
        	 Collections.sort(emp,new SortByFirstName());
        	 for(Employee employee1:emp)
             {
            	 System.out.println(employee1);
             }
         }
         else if(option==3)
         {
        	 Collections.sort(emp,new SortByLastName());
        	 for(Employee employee1:emp)
             {
            	 System.out.println(employee1);
             }
         }
         else if(option==4)
         {
        	 Collections.sort(emp,new SortBySalary());
        	 for(Employee employee1:emp)
             {
            	 System.out.println(employee1);
             }
         }
         else
         {
        	 System.out.println("Invalid Option");
        	 
         }
         System.out.println("Do u want to continue y or n?");
          str=sc.next();
         }while(str.charAt(0)=='y' || str.charAt(0)=='Y');
        
         
         

	}

}
