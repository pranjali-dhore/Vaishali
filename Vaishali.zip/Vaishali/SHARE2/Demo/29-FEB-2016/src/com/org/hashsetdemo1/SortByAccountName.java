package com.org.hashsetdemo1;

import java.util.Comparator;

import com.org.hashsetdemo.Employee;

public class SortByAccountName implements Comparator<Account>{
	

	@Override
	public int compare(Account account1, Account account2) {
		
		if(account1.getAccountName().compareTo(account2.getAccountName())>0)
			return 1;
		else if(account1.getAccountName().compareTo(account2.getAccountName())<0)
			return -1;
		else
		return 0;
	}
}
