package com.org.hashsetdemo1;

import java.util.Scanner;

public class BootClass {

	public static void main(String[] args) {
		
		UserInteraction user=new UserInteraction();
		Account account=new Account();
		AccountDao dao=new AccountDaoImplementation();
		Scanner sc=new Scanner(System.in);
		int option;
	    String str;
	    int accountId;
		do
		{
		System.out.println("1.Create Account");
		System.out.println("2.Delete Account");
		System.out.println("3.List all Account");
		System.out.println("4.Search Account");
		System.out.println("5.Update Account");
		System.out.println("Enter option=");
		option=sc.nextInt();
		
		switch(option)
		{
		case 1:
			account=user.getAccountDetails();
			System.out.println(account);
			break;
			
		case 3:
			dao.listAllAccount(account);
		case 4:
			 System.out.println("Enter Account Id To search=");
			 accountId=sc.nextInt();
			dao.searchAccount(accountId);
			 
		}
		System.out.println("Do you want to continue y or n?");
		str=sc.next();
		}while(str.charAt(0)=='y' ||str.charAt(0)=='Y');
	}

}
