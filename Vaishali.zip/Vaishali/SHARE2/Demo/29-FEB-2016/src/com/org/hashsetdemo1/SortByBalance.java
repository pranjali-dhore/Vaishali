package com.org.hashsetdemo1;

import java.util.Comparator;

public class SortByBalance implements Comparator<Account>{

	@Override
	public int compare(Account account1, Account account2) {
		
		if(account1.getOpenBalance()>account2.getOpenBalance())
			return 1;
		else if(account1.getOpenBalance()<account2.getOpenBalance())
			return -1;
		else
		return 0;
	}

}
