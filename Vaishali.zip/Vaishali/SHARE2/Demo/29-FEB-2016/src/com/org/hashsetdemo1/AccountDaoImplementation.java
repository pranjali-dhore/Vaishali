package com.org.hashsetdemo1;

public class AccountDaoImplementation implements AccountDao{

	@Override
	public void deleteAccount(int accountId) {
		
		
	}

	@Override
	public void listAllAccount(Account account) {
		
		System.out.println("Account Id="+account.getAccountId()+"\n"+"Open Date="+account.getOpenDate()+"\n"+"Account Type="+account.getAccountType()+"\n"+"open balance="+account.getOpenBalance());
	}

	@Override
	public void searchAccount(int accountId) {
		//Account account=new Account();
		//if(==accountId)
			//System.out.println("Account Id="+account.getAccountId()+"\n"+"Open Date="+account.getOpenDate()+"\n"+"Account Type="+account.getAccountType()+"\n"+"open balance="+account.getOpenBalance());
			
		
		
	}

	@Override
	public Account updateAccount(int accountId) {
		// TODO Auto-generated method stub
		return null;
	}

}
