package com.org.hashsetdemo1;

public interface AccountDao {

	public void deleteAccount(int accountId);
	public void listAllAccount(Account account);
	public void searchAccount(int accountId);
	public Account updateAccount(int accountId);
	
}
