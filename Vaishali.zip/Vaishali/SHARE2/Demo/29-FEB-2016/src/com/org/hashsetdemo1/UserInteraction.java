package com.org.hashsetdemo1;

import java.util.Date;
import java.util.Scanner;

public class UserInteraction {

	Account account=new Account();
	
	public Account getAccountDetails()
	{
		Scanner sc=new Scanner(System.in);
		int id=(int)Math.random()+1;
		account.setAccountId(id);
		
		System.out.println("Enter Account Name=");
		account.setAccountName(sc.next());
		
		
		System.out.println("Enter Open Date=");
		String date=sc.next();
		Date openDate=new Date(date);
		account.setOpenDate(openDate);
		
		System.out.println("Enter Account Type=");
		account.setAccountName(sc.next());
		
		System.out.println("Account Balance=");
		account.setOpenBalance(sc.nextDouble());
		return account;
		
	}
	
	/*public void showAccountDetails(Account account)
	{
		System.out.println("Account );
	}*/
}
