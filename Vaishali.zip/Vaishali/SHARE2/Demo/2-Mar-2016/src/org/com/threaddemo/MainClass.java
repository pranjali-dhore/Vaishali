package org.com.threaddemo;

public class MainClass {

	public static void main(String[] args) {

		ThreadDemo t2=new ThreadDemo("Welcome");
      ThreadDemo t1=new ThreadDemo("Capgemini");
      t1.start();
      t2.start();

	}

}
