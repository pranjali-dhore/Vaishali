package org.com.threaddemo;

public class ThreadDemo extends Thread{
	
	String myString;
	public ThreadDemo(String myString) 
	{
		this.myString=myString;
	}
	public void run()
	{
		
		for(int i=0;i<myString.length();i++)
		{
			for(int j=0;j<=i;j++)
			{
				System.out.print(myString.charAt(j));
				
			}
			System.out.println();
		}
	}
	

}
