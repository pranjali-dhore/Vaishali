package org.com.threaddemo1;

public class MainClass {

	public static void main(String[] args) {

       TableDemo t=new TableDemo();
       
       Thread t1=new Thread(t);
       
       t1.start();
       //t2.start();

	}

}
