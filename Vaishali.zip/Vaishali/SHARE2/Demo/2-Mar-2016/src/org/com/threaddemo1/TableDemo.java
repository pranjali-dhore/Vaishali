package org.com.threaddemo1;

public class TableDemo implements Runnable{

	int num;
	public static void printable()
	{
		for(int i=1;i<=num;i++)
		{
			System.out.println(i+"*"+num+"="+i*num);
			
		}
		
		
		
    }

	@Override
	public void run() {
		// TODO Auto-generated method stub
		printable();
	}
	}
	
