package com.org.demo;

public class Demo {

	 
	public static void main(String[] args) {

     int i=1;
     int j=i++;
     int _object;
    int _public;
     
    int[] a=new int[1];
    int b=a.length;
    
    String s="abc";
    int c=s.length();
   }
}
