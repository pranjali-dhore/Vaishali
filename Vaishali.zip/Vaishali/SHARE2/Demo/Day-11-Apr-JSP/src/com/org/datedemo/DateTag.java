package com.org.datedemo;

import java.io.IOException;
import java.io.StringWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class DateTag extends SimpleTagSupport{
	
	@Override
	public void doTag() throws JspException, IOException {
		
		JspWriter out=getJspContext().getOut();
		
	
		
		
		StringWriter str=new StringWriter();
		getJspBody().invoke(str);
		
		DateFormat dateFormat=new SimpleDateFormat("dd-MMM-yyyy");
		Date date=new Date();
		
		out.println(dateFormat.format(date));
		
	}
	
	

}
