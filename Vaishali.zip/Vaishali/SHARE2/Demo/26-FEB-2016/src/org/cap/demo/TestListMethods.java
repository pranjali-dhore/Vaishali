package org.cap.demo;

import java.io.LineNumberInputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class TestListMethods {

	public static void main(String[] args) {


		List<String> list=new ArrayList<>();
		
		List<String> list1=new ArrayList<>();
		
		
		list.add("Jerry");
		list.add("Tom");
		list.add("Ram");
		list.add("Jack");
		list.add("Tom");
		list.add("Jack");
		
		list1.add("Tom");
		list1.add("Jack");
		
		
		System.out.println("Size="+list.size());
		System.out.println("Get="+list.get(1));
		System.out.println("Is Empty="+list.isEmpty());
		System.out.println("contains="+list.contains("Jack"));
		System.out.println("addAll="+list.addAll(list));
		//list.clear();
		System.out.println("contains All="+list.containsAll(list1));
		System.out.println("Index of="+list.indexOf("Tom"));
		System.out.println("Last Index Of="+list.lastIndexOf("Jack"));
		
		System.out.println("Remove="+list.remove(1));
		System.out.println("Remove All="+list.removeAll(list1));
		
	
		
		
	
		
		
		
		

	}

}
