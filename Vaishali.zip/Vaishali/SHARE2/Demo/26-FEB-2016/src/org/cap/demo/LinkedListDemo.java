package org.cap.demo;

import java.util.LinkedList;

public class LinkedListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 LinkedList<Integer> list=new LinkedList<>();
		 
		 list.add(30);
		 list.add(50);
		 list.add(20);
		 list.add(60);
		 list.add(20);
		 list.add(10);
		 
		 System.out.println(list);
		 
		 System.out.println("Remove First="+list.removeFirst());
		 System.out.println("Remove Last="+list.removeLast());
		 list.addFirst(10);
		 list.addLast(100);
		 System.out.println("After add");
		 System.out.println(list);
		 System.out.println("Get First="+list.getFirst());
		 System.out.println("Get Last="+list.getLast());
		 
		 System.out.println("Offer="+list.offer(29));
		 System.out.println("Offer First="+list.offerFirst(66));
		 System.out.println(list.offerLast(99));
		 System.out.println("After Offer");
		 System.out.println(list);
		 System.out.println("Peek="+list.peek());
		
		 System.out.println("Peak First="+list.peekFirst());
		 System.out.println("Peak Last="+list.peekLast());
		 System.out.println("After Peek");
		 System.out.println(list);
		 System.out.println("Poll="+list.poll());
		 System.out.println("Poll Last="+list.pollFirst());
		 System.out.println("Poll First="+list.pollLast());
		 System.out.println("After Poll");
		 System.out.println(list);
		 System.out.println("Pop="+list.pop());
		 System.out.println("After Pop");
		 System.out.println(list);
		 list.push(20);
		 System.out.println("After Push");
		 System.out.println(list);
		 
		 System.out.println("Last Occurrence="+list.removeLastOccurrence(10));
		 System.out.println("After Last Occurrence");
		 System.out.println(list);
		 System.out.println("First Occurrence="+list.removeFirstOccurrence(20));
		 System.out.println("After First Occurrence");
		 System.out.println(list);
		
		 
		 
	}

}
