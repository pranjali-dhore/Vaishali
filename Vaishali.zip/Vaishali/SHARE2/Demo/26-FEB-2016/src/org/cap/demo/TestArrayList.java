package org.cap.demo;

import java.util.List;
import java.util.ListIterator;
import java.util.ArrayList;
import java.util.Iterator;

public class TestArrayList {

	public static void main(String[] args) {

        List<String> list=new ArrayList<>();
        List<Integer> list1=new ArrayList<>();
        
        list.add("Tom");
        list.add("Jerry");
        //list.add(null);
        list.add("null");
        list.add("Tom");
      
        
        list1.add(10);
        list1.add(20);
        
      
        //Iterator
        Iterator<String> itr=list.iterator();
        while(itr.hasNext())
        { 
        	String str=itr.next();
        	if(str.equals("Jerry"))
        		itr.remove();
        	System.out.println(str);
        }
        //ListIterator
        ListIterator<String> litr=list.listIterator();
        while(litr.hasNext())
        {
        	String str=litr.next();
        	if(str.equals("null"))
        		itr.remove();
        			
        	System.out.println(str);
        	
        }
        
        System.out.println();
        
        while(litr.previous() != null)
        	
        {
        	System.out.println(litr.previous());
        } 
        
        }
        
	}


