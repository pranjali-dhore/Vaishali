package org.com.customerdemo;

import java.util.Scanner;

public class UserInteraction {
	
	public Customer getCustomerDetails()
	{
	   Customer customer=new Customer();
	   
	   Scanner sc=new Scanner(System.in);
	   System.out.println("Enter Customer Id=");
	  customer.setCustId(sc.nextInt());
	  
	  System.out.println("Enter Customer Name=");
	  customer.setCustName(sc.next());
	  
	  System.out.println("Enter Registration Fees=");
	  customer.setRegFees(sc.nextDouble());
	  
	   
	   
	   return customer;
	   
	}

}
