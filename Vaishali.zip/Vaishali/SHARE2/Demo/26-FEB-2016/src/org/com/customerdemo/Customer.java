package org.com.customerdemo;

import java.util.Date;

public class Customer {
	
	private int custId;
	private String custName;
	private double regFees;
	private Date regDate;
	private String address;
	
	public Customer(){}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public double getRegFees() {
		return regFees;
	}

	public void setRegFees(double regFees) {
		this.regFees = regFees;
	}

	public Date getRegDate() {
		return regDate;
	}

	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custName=" + custName + ", regFees=" + regFees + ", regDate=" + regDate
				+ ", address=" + address + "]";
	}
	
	

}
