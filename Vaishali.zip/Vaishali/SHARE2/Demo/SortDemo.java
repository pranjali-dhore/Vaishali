import java.util.Scanner;

public class SortDemo
{
public static void main(String[] args)
{
    final int SIZE=10;
     Scanner sc=new Scanner(System.in);
	 
	 int[] myArr=new int[SIZE];
	 int[] temp=new int[SIZE];
	 System.out.println("Enter the Numbers=");
	 for(int i=0;i<SIZE;i++)
	 {
	    myArr[i]=sc.nextInt();
	 }
	 System.out.println("Array Elements");
	 for(int i=0;i<myArr.length;i++)
	 {
	    System.out.println(myArr[i]);
		}
				
		for(int j=0;j<SIZE-1;j++)
	 {
		for(int i=0;i<SIZE-1;i++)
	 {
	      if(myArr[i]>myArr[i+1])
		   {
		      temp[i]=myArr[i];
			  myArr[i]=myArr[i+1];
			  myArr[i+1]=temp[i];
			  }
		}	
		}
        System.out.println("Sorted Numbers");
		for(int i=0;i<myArr.length;i++)
	 {
	    System.out.println(myArr[i]);
		}
	   
		
		
		}
		}
		