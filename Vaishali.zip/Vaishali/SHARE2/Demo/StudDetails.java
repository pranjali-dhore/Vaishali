import java.util.Scanner;

public class StudDetails
{
   public static void main(String[] args)
{
      String firstName,lastName,address;
      int java,servlet,html;
      //float average;
     
    Scanner sc=new Scanner(System.in);

   System.out.println("Enter First Name=");
   firstName=sc.next();

   System.out.println("Enter Last Name=");
   lastName=sc.next();
   
   System.out.println("Enter Address=");
   address=sc.next();

   System.out.println("Enter Marks of Java=");
   java=sc.nextInt();

  System.out.println("Enter Marks of Servlet=");
  servlet=sc.nextInt();

  System.out.println("Enter Marks of html=");
  html=sc.nextInt();

  System.out.println("FirstName="+firstName);
 System.out.println("LastName="+lastName);
 System.out.println("Address="+address);
   System.out.println(" Total="+(java+servlet+html));
 System.out.println("Average="+((java+servlet+html)/3));

}
}
