import java.util.Scanner;

public class EvenDemo
{

public static void main(String[] args)
{
    final int SIZE=4;
     Scanner sc=new Scanner(System.in);
	 int temp=0;
	 int[] myArr=new int[SIZE];
	 System.out.println("Enter the Numbers=");
	 for(int i=0;i<SIZE;i++)
	 {
	    myArr[i]=sc.nextInt();
	 }
	 System.out.println("Array Elements=");
	 for(int i=0;i<myArr.length;i++)
	 {
	    
	    System.out.println(myArr[i]);
		}
		System.out.println("EvenNumbers=");
		for(int i=0;i<myArr.length;i++)
	 {
	     
		if(myArr[i]%2==0)
		{
		   
		   System.out.println(myArr[i]);
		 
		}
		}
		
		
		
		}
		}