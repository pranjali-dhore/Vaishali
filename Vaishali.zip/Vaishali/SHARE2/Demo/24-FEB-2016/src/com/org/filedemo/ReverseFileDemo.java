package com.org.filedemo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ReverseFileDemo {

	public static void main(String[] args) {

        File file=new File("D:\\Users\\vaishpaw\\Demo\\myFile.txt");
        
       FileReader filereader=null;
      
    	   
    		   try {
				filereader=new FileReader(file);
				long size=file.length();
				int len=(int)size;
				int i=0;
				char[] ch=new char[(int)size];
				while(size>0)
				{
					
					ch[i]=(char)filereader.read();
					System.out.print(ch[i]);
					size--;
					i++; 
					
				}
		    	 

				System.out.println();
				
				for(int j=len-1;j>=0;j--){
					System.out.print(ch[j]);
				}
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    		    catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    		   finally
    		   {
    			   try {
					filereader.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    		   }
    	   
	}
	}
    	 
       
	


