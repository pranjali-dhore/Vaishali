package com.org.filedemo;

import java.io.DataInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileInputDEmo {

	 
	public static void main(String[] args)  {
		  
        File file=new File("D:\\Users\\vaishpaw\\Demo\\FileFormat.txt");
        FileInputStream fin=null;
        DataInputStream din=null;
     
        
			  try {
				 
				    fin=new FileInputStream(file);
			
			        din=new DataInputStream(fin);
			  
			   long size=file.length();
			   while(size>=0)
			   {
				   
				int eid=din.readInt();
			
			  double salary=din.readDouble();
			  char gender=din.readChar();
			  boolean isPermanent=din.readBoolean();
			  String name=din.readLine();
			  size++;
			  System.out.println("Employee Id="+eid+"\n Salary="+salary+"\n Gender="+gender+"\n Is Permanent="+isPermanent+"\n Name="+name);
			   }
			
			  } catch (FileNotFoundException|EOFException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
			  catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			  finally
			  {
				  try {
					fin.close();
					din.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				  
			  }
	}

}
