package com.org.filedemo;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class ObjectInputOutput {

	public static void main(String[] args) {
          
		     File file=new File("D:\\Users\\vaishpaw\\Demo\\Employee.dat");
		   UserInteraction interaction=new UserInteraction();
		   Employee emp=new Employee();
		   
		   ObjectOutputStream objout=null;
			FileOutputStream fout=null;
			
			 ObjectInputStream objin=null;
				FileInputStream fin=null;
				
          Scanner sc=new Scanner(System.in);
          String str;
          int option;
          
          do
          {
        	  try {
        	        fout=new FileOutputStream(file);
  			        objout=new ObjectOutputStream(fout);
  			        
  			        fin=new FileInputStream(file);
  			        objin=new ObjectInputStream(fin);
			
          System.out.println("1.Save Employee");
          System.out.println("2.List all Employee");
          System.out.println("3.Delete Employee");
          System.out.println("4.Find Employee");
          
          System.out.println("Enter your option=");
           option=sc.nextInt();
          //write Object
          if(option==1)
          {
        	emp=interaction.getEmployee(); 
        	objout.writeObject(emp);
          }
          
        	
      			//Read Object
          
          else if(option==2)
          {
    		  try {
    			  emp=(Employee)objin.readObject();
    			  while(emp!=null)
    			  {
				
				interaction.showDetails(emp);
				emp=(Employee)objin.readObject();
    			  }
			} catch (ClassNotFoundException|EOFException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    		 
          }
          
      } catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	  finally{
  			try {
  				objout.close();
  				fout.close();
  				fin.close();
  				objin.close();
  			} catch (IOException e) {
  				// TODO Auto-generated catch block
  				e.printStackTrace();
  			}
  			
      			        
      		}
        	  System.out.println("Do u want to continue y or n?");
              str=sc.next();
              }while(str.charAt(0)=='y' || str.charAt(0)=='Y');
	}

}
