package com.org.filedemo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileCopyDemo {

	public static void main(String[] args) {

		File file=new File("D:\\Users\\vaishpaw\\Demo\\myFile.txt");
		File file1=new File("D:\\Users\\vaishpaw\\Demo\\fileCopy.txt");
		 FileReader filereader=null;
	      FileWriter filewriter=null;
  	   
		   try {
			filereader=new FileReader(file);
			filewriter=new FileWriter(file1);
			if(file1.exists())
			{
			long size=file.length();
			int len=(int)size;
			int i=0;
			char ch;
			while(size>0)
			{
				
				ch=(char)filereader.read();
				filewriter.write(ch);
				size--;
			    i++;
				
			}
             
			
			

			}	
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		    catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		   finally
		   {
			   try {
				filereader.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		   }
	   
	}

}
