package com.org.filedemo;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class FormatOutputDemo {

	public static void main(String[] args) {

         int empId;
         String empName;
         double salary;
         boolean isPermanent;
        String gender;
         
         File file=new File("D:\\Users\\vaishpaw\\Demo\\FileFormat.txt");
         FileOutputStream fout=null;
         DataOutputStream dout=null;
         
         try {
			fout=new FileOutputStream(file,true);
			dout=new DataOutputStream(fout);
			String str;
			do
			{
				Scanner sc=new Scanner(System.in);
			   System.out.println("Enter Employee Id=");
			    empId=sc.nextInt();
				dout.writeInt(empId);
				 System.out.println("Enter Salary=");
				    salary=sc.nextInt();
				dout.writeDouble(salary);
				 System.out.println("Enter Gender=");
				    gender=sc.next();
				    dout.writeChar(gender.charAt(0));
				 System.out.println("Enter isPermanent=");
				    isPermanent=sc.nextBoolean();
				dout.writeBoolean(isPermanent);
				 System.out.println("Enter Employee Name=");
				    empName=sc.next();
				dout.writeChars(empName);
				System.out.println("Do you want to continue y or n?");
				str=sc.next();
			}while(str.charAt(0)=='y');
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
         catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
         finally
         {
        	 try {
				fout.close();
				 dout.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	
         }
	}

}
