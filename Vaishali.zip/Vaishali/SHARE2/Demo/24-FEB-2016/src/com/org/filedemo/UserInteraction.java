package com.org.filedemo;

import java.util.Scanner;

public class UserInteraction {

	
	public Employee getEmployee()
	{
		Employee emp=new Employee();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter employee Id=");
		emp.setEmpId(sc.nextInt());
		
		System.out.println("Enter First Name=");
		emp.setFirstName(sc.next());
		
		System.out.println("Enter Last Name=");
		emp.setLastName(sc.next());
		
		System.out.println("Enter Salary=");
		emp.setSalary(sc.nextDouble());
		
		return emp;
		
	}
	
	public void showDetails(Employee emp)
	{
		System.out.println("Employee Id="+emp.getEmpId()+"First Name="+emp.getFirstName()+"Last Name="+emp.getLastName()+"Salary="+emp.getSalary());
	}
}
