import java.util.Scanner;
 
class MatrixMultiplication
{
   public static void main(String args[])
   {
      int row1, row2,col1,col2, sum = 0, i,j,k;
 
      Scanner sc= new Scanner(System.in);
      System.out.println("Enter the number of rows and columns of first matrix");
      row1= sc.nextInt();
      col1= sc.nextInt();
 
      int mat1[][] = new int[row1][col1];
 
      System.out.println("Enter the elements of first matrix");
 
      for ( i = 0 ; i < row1 ; i++ )
         for ( j= 0 ;j < col1 ; j++ )
            mat1[i][j] = sc.nextInt();
 
      System.out.println("Enter the number of rows and columns of second matrix");
       row2= sc.nextInt();
       col2=  sc.nextInt();
 
      if ( col1!= row2 )
         System.out.println("Matrices cannot  be multiplied");
      else
      {
         int mat2[][] = new int[row2][col2];
         int multiply[][] = new int[row1][col1];
 
         System.out.println("Enter the elements of second matrix");
 
         for (i = 0 ; i< row2 ; i++ )
            for (j= 0 ; j<col2 ; j++ )
               mat2[i][j] = sc.nextInt();
 
         for ( i= 0; i< row2; i++ )
         {
            for ( j= 0 ; j<col2 ; j++ )
            {   
               for ( k = 0 ; k <col2 ; k++ )
               {
                  sum = sum + mat1[i][k]*mat2[k][j];
               }
 
               multiply[i][j] = sum;
               sum = 0;
            }
         }
 
         System.out.println("Product of entered matrices:-");
 
         for ( i= 0 ; i<row1 ; i++ )
         {
            for (j= 0 ; j< col1 ; j++ )
               System.out.print(multiply[i][j]+"\t");
 
            System.out.print("\n");
         }
      }
   }
}