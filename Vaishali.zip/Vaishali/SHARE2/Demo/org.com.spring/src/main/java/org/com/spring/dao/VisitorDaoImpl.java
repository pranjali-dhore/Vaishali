package org.com.spring.dao;

import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.com.spring.Address;
import org.com.spring.AddressRow;
import org.com.spring.Visitor;
import org.com.spring.VisitorRow;
import org.springframework.jdbc.core.JdbcTemplate;

public class VisitorDaoImpl implements VisitorDao{
	
	
	private JdbcTemplate jdbcTemplate;
	private DataSource dataSource;

	public void setDataSource(DataSource dataSource) {
		this.dataSource=dataSource;
		jdbcTemplate=new JdbcTemplate(dataSource);
		
	}

	public void createVisitor(Visitor visitor) {
		
		String sql1="insert into address(streetName,city,doorNo,state) values(?,?,?,?)";
		jdbcTemplate.update(sql1,visitor.getAddress().getStreetName(),visitor.getAddress().getCity(),visitor.getAddress().getDoorNo(),visitor.getAddress().getCity());
		
		int id=jdbcTemplate.queryForInt("select addressId from address order by addressId desc limit 1");
		String sql="insert into visitors(visitorName,addressId) values(?,?)";
		jdbcTemplate.update(sql, visitor.getVisitorName(),id);
		
		int id1=jdbcTemplate.queryForInt("select visitorId from visitors order by visitorId desc limit 1");
		sql="update address set visitorId =? where addressId=?";
		jdbcTemplate.update(sql,new Object[]{id1,id});
		
		System.out.println("Created");

		
		
	}

	public void deleteVisitor(int visitorId) {
		int id=jdbcTemplate.queryForInt("select addressId from visitors where visitorId=?",visitorId);
        String sql="delete from visitors where visitorId=?";
		
		jdbcTemplate.update(sql, visitorId);
		sql="delete from address where addressId=?";
		jdbcTemplate.update(sql, id);
		System.out.println("Deleted");
	}

	public void updateVisitor(Visitor visitor) {
		
		String sql="update visitors set visitorName=? where visitorId=?";
		jdbcTemplate.update(sql,new Object[]{visitor.getVisitorId(),visitor.getVisitorName()});
		sql="update address set streetName=?,city=?,doorNo=?,state=? where visitorId=?";
		jdbcTemplate.update(sql,new Object[]{visitor.getAddress().getStreetName(),visitor.getAddress().getCity(),visitor.getAddress().getDoorNo(),visitor.getAddress().getState()});
		System.out.println("Updated");
		
		
		
	}

	public Visitor searchVisitor(int visitorId) {
		String sql="select * from visitors where visitorId=?";
	Visitor visitor=jdbcTemplate.queryForObject(sql,new Object[]{visitorId} , new VisitorRow());
		
		return visitor;
	}

	public List<Visitor> getAllVisitors() {
		List<Visitor> visitors= new ArrayList<Visitor>();
		List<Visitor> resultvisitors= new ArrayList<Visitor>();
		String sql="select count(visitorId) from visitors";
		int id=jdbcTemplate.queryForInt(sql);
		sql="select * from visitors ";
		visitors=jdbcTemplate.query(sql,new Object[]{} , new VisitorRow());
		for(Visitor v:visitors)	
		{
			sql="select * from address where address_id=?";
			Address address=jdbcTemplate.queryForObject(sql, new Object[]{v.getVisitorId()},new AddressRow());
			v.setAddress(address);
			resultvisitors.add(v);
			
		}
		return resultvisitors;
	}
	

	

}
