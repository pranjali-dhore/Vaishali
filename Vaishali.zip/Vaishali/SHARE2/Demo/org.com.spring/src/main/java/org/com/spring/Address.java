package org.com.spring;

public class Address {

	   private int addressId;
	   private String streetName;
	   private String city;
	   private int doorNo;
	   private String state;
	   
	   public Address(){}

	public Address(int addressId, String streetName, String city, int doorNo, String state) {
		super();
		this.addressId = addressId;
		this.streetName = streetName;
		this.city = city;
		this.doorNo = doorNo;
		this.state = state;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getDoorNo() {
		return doorNo;
	}

	public void setDoorNo(int doorNo) {
		this.doorNo = doorNo;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", streetName=" + streetName + ", city=" + city + ", doorNo="
				+ doorNo + ", state=" + state + "]";
	}
	   
	   
	
}
