package org.com.spring;

import java.util.List;
import java.util.Scanner;

import org.com.spring.dao.VisitorDaoImpl;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		ApplicationContext context=new ClassPathXmlApplicationContext("jdbcBeans.xml");
		
		VisitorDaoImpl visitorDao=(VisitorDaoImpl) context.getBean("jdbcTemp");
		
		System.out.println("Main Menu\n");
		System.out.println("1.Create Visitor\n");
		System.out.println("2.Update Visitor\n");
		System.out.println("3.Delete Visitor\n");
		System.out.println("4.Search Visitor\n");
		System.out.println("5.List All Visitor\n");
		System.out.println("Enter your choice:");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1: System.out.println("Enter Visitor Name");
				String name=sc.next();
				System.out.println("Enter Address");
				
				System.out.println("Enter DoorNo");
				int doorno=sc.nextInt();
				System.out.println("Enter Street Name");
				String streetname=sc.next();
				System.out.println("Enter City");
				String city=sc.next();
				System.out.println("Enter State");
				String state=sc.next();
				
				Address address=new Address();
				address.setDoorNo(doorno);
				address.setStreetName(streetname);
				address.setCity(city);
				address.setState(state);
				Visitor visitor=new Visitor();
				visitor.setVisitorName(name);
				visitor.setAddress(address);
				visitorDao.createVisitor(visitor);
				break;
				
		case 2:
			       //Update Visitor
			       
			        System.out.println("Enter Visitor Name");
					String name1=sc.next();
					System.out.println("Enter Address");
					
					System.out.println("Enter DoorNo");
					int doorno1=sc.nextInt();
					System.out.println("Enter Street Name");
					String streetname1=sc.next();
					System.out.println("Enter City");
					String city1=sc.next();
					System.out.println("Enter State");
					String state1=sc.next();
					
					Address address1=new Address();
					address1.setDoorNo(doorno1);
					address1.setStreetName(streetname1);
					address1.setCity(city1);
					address1.setState(state1);
					visitor=new Visitor();
					visitor.setVisitorName(name1);
					visitor.setAddress(address1);
					
			        visitorDao.updateVisitor(visitor);
			     break;
		case 3:
			     //Delete visitor
			  System.out.println("Enter visitor id=");
                int visitorId1=sc.nextInt();    
		         Visitor visitor2=visitorDao.searchVisitor(visitorId1);
		        System.out.println(visitor2);
			  break; 
		case 4: //Search Visitor 
			      System.out.println("Enter visitor id=");
	              int visitorId=sc.nextInt();    
			     Visitor visitor1=visitorDao.searchVisitor(visitorId);
			     System.out.println(visitor1);
			  break; 
		case 5: 
			    //List All Visitors
			   List<Visitor> visitors=visitorDao.getAllVisitors();
		         for(Visitor vis:visitors)
		         {
		        	 System.out.println(vis);
		         }
			  break; 
		}
		
		
	}
}
