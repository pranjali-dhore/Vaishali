package org.com.spring;

public class Visitor {

	  private int visitorId;
	  private String visitorName;
	  private Address address;
	  
	  public Visitor(){}

	public Visitor(int visitorId, String visitorName, Address address) {
		super();
		this.visitorId = visitorId;
		this.visitorName = visitorName;
		this.address = address;
	}

	public int getVisitorId() {
		return visitorId;
	}

	public void setVisitorId(int visitorId) {
		this.visitorId = visitorId;
	}

	public String getVisitorName() {
		return visitorName;
	}

	public void setVisitorName(String visitorName) {
		this.visitorName = visitorName;
	}

	public Address getAddress() {
		return address;
	}

	

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Visitor [visitorId=" + visitorId + ", visitorName=" + visitorName + ", address=" + address + "]";
	}
	  
	  
}
