package org.com.spring.dao;

import java.util.List;

import javax.sql.DataSource;

import org.com.spring.Visitor;

public interface VisitorDao {
	

	public void setDataSource(DataSource dataSource);
	public void createVisitor(Visitor visitor);
	
	public void deleteVisitor(int visitorId);
	
	public void updateVisitor(Visitor visitor);
	
	public Visitor searchVisitor(int visitorId);
	
	public List<Visitor> getAllVisitors();


}
