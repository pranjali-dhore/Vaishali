package org.com.spring;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class AddressRow implements RowMapper<Address>{

	public Address mapRow(ResultSet rs, int rowNum) throws SQLException {
		Address address=new Address();
		address.setAddressId(rs.getInt(1));
		address.setStreetName(rs.getString(2));
		address.setCity(rs.getString(3));
		address.setDoorNo(rs.getInt(4));
		address.setState(rs.getString(5));
		
		return address;
	}

}
