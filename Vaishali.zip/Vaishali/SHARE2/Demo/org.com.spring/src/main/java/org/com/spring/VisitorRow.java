package org.com.spring;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class VisitorRow implements RowMapper<Visitor>{

	public Visitor mapRow(ResultSet rs, int count) throws SQLException {
		Visitor visitor=new Visitor();
		visitor.setVisitorId(rs.getInt(1));
		visitor.setVisitorName(rs.getString(2));
		
		visitor.setAddress((Address) rs.getObject(3));
		
		return visitor;
	}

	
}
