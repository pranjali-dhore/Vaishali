import java.util.Scanner;

public class FiboSeries
{
public static void main(String[] args)
{
   int firstNum=0,secondNum=1,thirdNum;
     int i=0,num;
	        Scanner sc=new Scanner(System.in);
			System.out.println("Enter Number=");
			num=sc.nextInt();
	       System.out.println(firstNum);
		   System.out.println(secondNum);
	         for(i=0;i<num;i++)
			 {
		      thirdNum=firstNum+secondNum;
			  System.out.println(thirdNum);
			  firstNum=secondNum;
			  secondNum=thirdNum;
			  }
			  }
			  
}