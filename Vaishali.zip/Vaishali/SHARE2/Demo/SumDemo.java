import java.util.Scanner;

public class SumDemo
{
public static void main(String[] args)
{
    final int SIZE=4;
     Scanner sc=new Scanner(System.in);
	 int temp=0;
	 int[] myArr=new int[SIZE];
	 System.out.println("Enter the Numbers=");
	 for(int i=0;i<SIZE;i++)
	 {
	    myArr[i]=sc.nextInt();
	 }
	 for(int i=0;i<myArr.length;i++)
	 {
	    temp=temp+(myArr[i]);
	    System.out.println(myArr[i]);
		 
		}
		System.out.println("Sum of Array="+temp);
		
		}
		}