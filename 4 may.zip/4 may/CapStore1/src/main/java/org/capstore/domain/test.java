package org.capstore.domain;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnnotationConfiguration  config = new AnnotationConfiguration();
		config.configure();
		new SchemaExport(config).create(true, true);
		SessionFactory sessionfactory = config.buildSessionFactory();
		Session session = sessionfactory.openSession();
		session.beginTransaction();
		Login login = new Login();
		session.save(login);
		session.getTransaction().commit();
		session.close();
	}

}
