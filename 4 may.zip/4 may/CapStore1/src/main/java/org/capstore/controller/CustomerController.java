package org.capstore.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.capstore.domain.Customer;
import org.capstore.domain.Login;
import org.capstore.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class CustomerController {
	

	
	@Autowired
	private CustomerService customerService;

	@RequestMapping("/customer")
	public String showCustomerPage(Map<String, Object> map){
		
				map.put( "customer", new Customer());
				//map.put("custtype", getAllCustomerType().values());
				//map.put("customers", customerService.getAllCustomers());
				
				return "customerRegister";
	}
	
	@RequestMapping(value="/saveCustomer",method=RequestMethod.POST)
	public ModelAndView saveCustomer(@Valid @ModelAttribute("customer") Customer customer,
			BindingResult result){
		
		if(!result.hasErrors()){
			System.out.println(customer);
			customerService.saveCustomer(customer);
			return new ModelAndView("customer");
		}else
		{
			return new ModelAndView("customerRegister");
		}
	
	}
	
	
	@RequestMapping("/updateCustomerPwd")
	public String showChangePwdPage(Map<String, Object> map){
		
				map.put( "customer", new Customer());
				//map.put("custtype", getAllCustomerType().values());
				//map.put("customers", customerService.getAllCustomers());
				
				return "changePwd";
	}
	
/*	
	@RequestMapping("/login")
	public String validateUser(@ModelAttribute("login") Customer login,
			BindingResult result){
		
	Customer login = new Customer();
		login.setEmail_id("rahul@gmail.com");
		login.setPassword("rahul");
		
		
		
		return "login";
		
	}*/
	@RequestMapping(value="/updateCustomer",method=RequestMethod.POST)
	public String  updateCustomerPwd(@Valid @ModelAttribute("customer") Customer customer,
			BindingResult result,HttpServletRequest request){
		/* boolean flag=true;
		 String email_id1=request.getParameter("email_id");
		String pass=request.getParameter("password");
		Customer cust=customerService.searchCustomer(request.getParameter("email_id"));
		System.out.println(cust);
	
		
		customerService.updateCustomer(cust);
		cust.setPassword(pass);
		System.out.println(cust);
		customerService.saveCustomer(cust);
		//}
		//customerService.searchCustomer(email_id)=cust;
	//searchCustomer=cust;
		 //System.out.println("Hello");
		//return"redirect:/changePwd";
		*/
		
		/*customer.setPassword(request.getParameter("password"));
		 System.out.println(customer);*/
	/*	List<Customer> customers=new Arraylist<>();
		customerService.getAllCustomer();*/
		String password = customer.getPassword();
		String email_id= customer.getEmail_id();
		
		System.out.println(password+""+ email_id);
		  customerService.updateCustomer(customer);
		  System.out.println(customer);
	       return"redirect:/changePwd";
}
	
	
/*
	@RequestMapping("/userlogin")
	public String showPage(@ModelAttribute("customer") Customer customer,BindingResult result)	
	{	System.out.println(customer);
		
		boolean flag = customerService.isvaliduser(customer);
	
		System.out.println(flag);
		if(flag)
			
			
			
			return "customer";
		else
			return "login";
	}
*/
/*
	@RequestMapping(value="/saveLogin",method=RequestMethod.POST)
	public ModelAndView saveCustomer(@Valid @ModelAttribute("login") Login login,
			BindingResult result){
		
		if(!result.hasErrors()){
			System.out.println(login);
			customerService.saveLogin(login);
			return new ModelAndView("login");
		}else
		{
			return new ModelAndView("login");
		}
	
	}
	*/
}
