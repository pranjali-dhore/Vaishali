package org.capstore.service;

import java.util.List;

import org.capstore.domain.Customer;
import org.capstore.domain.Login;
import org.springframework.stereotype.Service;

@Service
public interface CustomerService {
	
	public void saveCustomer(Customer customer);
	public Customer searchCustomer(String email_id);
	public void deletecustomer(String email_id);
	/*	public Customer updateCustomer(String password, String email_id);*/
	public void saveLogin(Login login) ;
	public void updateCustomer(Customer customer);
	public boolean isvaliduser(Customer customer);
	public List<Customer> getAllCustomer();
}
