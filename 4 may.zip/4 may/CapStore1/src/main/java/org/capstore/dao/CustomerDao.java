package org.capstore.dao;

import java.util.List;

import org.capstore.domain.Customer;
import org.capstore.domain.Login;

public interface CustomerDao {
	
	public void saveCustomer(Customer customer);
	public Customer searchCustomer(String email_id);
	public void deletecustomer(String email_id);
	/*public Customer updateCustomer(String password,String email_id);*/
	public void updateCustomer(Customer customer);
	public void saveLogin(Login login);
	public boolean isvaliduser(Customer customer);
	public List<Customer> getAllCustomer();
}
