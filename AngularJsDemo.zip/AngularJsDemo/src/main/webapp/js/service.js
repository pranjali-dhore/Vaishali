app.controller("myCtrl",function($scope)
{
$scope.companyName="Capgemini India Pvt Ltd";
	
	$scope.myFunc=function(){
		alert('Hello! Welcome To Angular!');
	};
	
	
	
	
});
